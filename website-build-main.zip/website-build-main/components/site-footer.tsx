"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Facebook, Instagram, TwitterIcon as TikTok, Phone } from "lucide-react"
import { getSiteSettings } from "@/lib/db-utils"

export function SiteFooter() {
  const [settings, setSettings] = useState<any>({})
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function loadSettings() {
      try {
        const siteSettings = await getSiteSettings()
        setSettings(siteSettings)
      } catch (error) {
        console.error("Error loading site settings:", error)
      } finally {
        setLoading(false)
      }
    }

    loadSettings()
  }, [])

  if (loading) {
    return <div className="h-40 bg-gray-100 animate-pulse"></div>
  }

  const socialMedia = settings.social_media || {}

  return (
    <footer className="bg-gray-100">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-bold mb-4">{settings.site_name || "NepalMart"}</h3>
            <p className="text-muted-foreground mb-4">{settings.site_description}</p>
            <div className="flex space-x-4">
              {socialMedia.facebook && (
                <a
                  href={socialMedia.facebook}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-600 hover:text-primary"
                >
                  <Facebook className="h-5 w-5" />
                </a>
              )}
              {socialMedia.instagram && (
                <a
                  href={socialMedia.instagram}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-600 hover:text-primary"
                >
                  <Instagram className="h-5 w-5" />
                </a>
              )}
              {socialMedia.tiktok && (
                <a
                  href={socialMedia.tiktok}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-600 hover:text-primary"
                >
                  <TikTok className="h-5 w-5" />
                </a>
              )}
              {socialMedia.whatsapp && (
                <a
                  href={`https://wa.me/${socialMedia.whatsapp}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-600 hover:text-primary"
                >
                  <Phone className="h-5 w-5" />
                </a>
              )}
            </div>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-muted-foreground hover:text-primary">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/products" className="text-muted-foreground hover:text-primary">
                  Products
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-muted-foreground hover:text-primary">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-muted-foreground hover:text-primary">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4">Customer Service</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/faq" className="text-muted-foreground hover:text-primary">
                  FAQ
                </Link>
              </li>
              <li>
                <Link href="/shipping" className="text-muted-foreground hover:text-primary">
                  Shipping Policy
                </Link>
              </li>
              <li>
                <Link href="/returns" className="text-muted-foreground hover:text-primary">
                  Returns & Refunds
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="text-muted-foreground hover:text-primary">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/terms" className="text-muted-foreground hover:text-primary">
                  Terms & Conditions
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4">Contact Us</h3>
            <address className="not-italic text-muted-foreground">
              <p>{settings.contact_address}</p>
              <p className="mt-2">
                Email:{" "}
                <a href={`mailto:${settings.contact_email}`} className="hover:text-primary">
                  {settings.contact_email}
                </a>
              </p>
              <p className="mt-2">
                Phone:{" "}
                <a href={`tel:${settings.contact_phone}`} className="hover:text-primary">
                  {settings.contact_phone}
                </a>
              </p>
            </address>
          </div>
        </div>

        <div className="border-t border-gray-200 mt-12 pt-8 text-center text-muted-foreground">
          <p>
            &copy; {new Date().getFullYear()} {settings.site_name || "NepalMart"}. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  )
}
