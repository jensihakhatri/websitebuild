"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { useAuth } from "@/components/auth-provider"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ThemeToggle } from "@/components/theme-toggle"
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle,
} from "@/components/ui/navigation-menu"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { cn } from "@/lib/utils"
import { signOut } from "firebase/auth"
import { auth } from "@/lib/firebase"
import {
  Search,
  ShoppingCart,
  User,
  Menu,
  Heart,
  LogOut,
  Settings,
  Package,
  Home,
  Phone,
  ShoppingBag,
  Clock,
  HelpCircle,
  FileText,
  TruckIcon,
  RefreshCw,
  ShieldCheck,
} from "lucide-react"

export default function Header() {
  const { user, isAdmin } = useAuth()
  const pathname = usePathname()
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const handleSignOut = async () => {
    try {
      await signOut(auth)
      router.push("/auth/login")
    } catch (error) {
      console.error("Error signing out:", error)
    }
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      router.push(`/products?search=${encodeURIComponent(searchQuery)}`)
    }
  }

  // If not mounted yet, show minimal header to prevent hydration mismatch
  if (!mounted) {
    return (
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <ShoppingBag className="h-6 w-6" />
            <span className="font-bold">NextCommerce</span>
          </Link>
          <div className="flex items-center gap-2">
            <ThemeToggle />
          </div>
        </div>
      </header>
    )
  }

  // If user is not logged in, show minimal header with login/register buttons
  if (!user) {
    return (
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <ShoppingBag className="h-6 w-6" />
            <span className="font-bold">NextCommerce</span>
          </Link>
          <div className="flex items-center gap-4">
            <ThemeToggle />
            <Link href="/auth/login">
              <Button variant="outline">Sign In</Button>
            </Link>
            <Link href="/auth/register">
              <Button>Register</Button>
            </Link>
          </div>
        </div>
      </header>
    )
  }

  // Full header for logged in users
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-6 md:gap-10">
          <Link href="/" className="flex items-center space-x-2">
            <ShoppingBag className="h-6 w-6" />
            <span className="hidden font-bold sm:inline-block">NextCommerce</span>
          </Link>

          <nav className="hidden md:flex gap-6">
            <NavigationMenu>
              <NavigationMenuList>
                <NavigationMenuItem>
                  <Link href="/" legacyBehavior passHref>
                    <NavigationMenuLink className={navigationMenuTriggerStyle()}>Home</NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <NavigationMenuTrigger>Shop</NavigationMenuTrigger>
                  <NavigationMenuContent>
                    <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2 lg:w-[600px]">
                      <li className="row-span-3">
                        <NavigationMenuLink asChild>
                          <a
                            className="flex h-full w-full select-none flex-col justify-end rounded-md bg-gradient-to-b from-muted/50 to-muted p-6 no-underline outline-none focus:shadow-md"
                            href="/products"
                          >
                            <ShoppingBag className="h-6 w-6" />
                            <div className="mb-2 mt-4 text-lg font-medium">All Products</div>
                            <p className="text-sm leading-tight text-muted-foreground">
                              Browse our complete collection of products
                            </p>
                          </a>
                        </NavigationMenuLink>
                      </li>
                      <li>
                        <Link href="/products?category=electronics" legacyBehavior passHref>
                          <NavigationMenuLink
                            className={cn(
                              "block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
                            )}
                          >
                            <div className="text-sm font-medium leading-none">Electronics</div>
                            <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                              Latest gadgets and electronic devices
                            </p>
                          </NavigationMenuLink>
                        </Link>
                      </li>
                      <li>
                        <Link href="/products?category=clothing" legacyBehavior passHref>
                          <NavigationMenuLink
                            className={cn(
                              "block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
                            )}
                          >
                            <div className="text-sm font-medium leading-none">Clothing</div>
                            <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                              Fashion and apparel for all seasons
                            </p>
                          </NavigationMenuLink>
                        </Link>
                      </li>
                      <li>
                        <Link href="/products?category=home-kitchen" legacyBehavior passHref>
                          <NavigationMenuLink
                            className={cn(
                              "block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
                            )}
                          >
                            <div className="text-sm font-medium leading-none">Home & Kitchen</div>
                            <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                              Everything for your home and kitchen needs
                            </p>
                          </NavigationMenuLink>
                        </Link>
                      </li>
                    </ul>
                  </NavigationMenuContent>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <Link href="/products?deals=true" legacyBehavior passHref>
                    <NavigationMenuLink className={navigationMenuTriggerStyle()}>Deals</NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <NavigationMenuTrigger>Help</NavigationMenuTrigger>
                  <NavigationMenuContent>
                    <ul className="grid gap-3 p-6 md:w-[400px] lg:w-[500px] lg:grid-cols-2">
                      <li>
                        <Link href="/contact" legacyBehavior passHref>
                          <NavigationMenuLink
                            className={cn(
                              "flex select-none items-center gap-2 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
                            )}
                          >
                            <Phone className="h-4 w-4" />
                            <div>
                              <div className="text-sm font-medium leading-none">Contact Us</div>
                              <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                                Get in touch with our customer service team
                              </p>
                            </div>
                          </NavigationMenuLink>
                        </Link>
                      </li>
                      <li>
                        <Link href="/shipping" legacyBehavior passHref>
                          <NavigationMenuLink
                            className={cn(
                              "flex select-none items-center gap-2 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
                            )}
                          >
                            <TruckIcon className="h-4 w-4" />
                            <div>
                              <div className="text-sm font-medium leading-none">Shipping Information</div>
                              <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                                Learn about our shipping policies and delivery times
                              </p>
                            </div>
                          </NavigationMenuLink>
                        </Link>
                      </li>
                      <li>
                        <Link href="/returns" legacyBehavior passHref>
                          <NavigationMenuLink
                            className={cn(
                              "flex select-none items-center gap-2 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
                            )}
                          >
                            <RefreshCw className="h-4 w-4" />
                            <div>
                              <div className="text-sm font-medium leading-none">Returns & Exchanges</div>
                              <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                                Our policies for returns and exchanges
                              </p>
                            </div>
                          </NavigationMenuLink>
                        </Link>
                      </li>
                      <li>
                        <Link href="/faq" legacyBehavior passHref>
                          <NavigationMenuLink
                            className={cn(
                              "flex select-none items-center gap-2 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
                            )}
                          >
                            <HelpCircle className="h-4 w-4" />
                            <div>
                              <div className="text-sm font-medium leading-none">FAQ</div>
                              <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                                Frequently asked questions about our products and services
                              </p>
                            </div>
                          </NavigationMenuLink>
                        </Link>
                      </li>
                      <li>
                        <Link href="/privacy" legacyBehavior passHref>
                          <NavigationMenuLink
                            className={cn(
                              "flex select-none items-center gap-2 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
                            )}
                          >
                            <ShieldCheck className="h-4 w-4" />
                            <div>
                              <div className="text-sm font-medium leading-none">Privacy Policy</div>
                              <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                                Information about how we protect your privacy
                              </p>
                            </div>
                          </NavigationMenuLink>
                        </Link>
                      </li>
                    </ul>
                  </NavigationMenuContent>
                </NavigationMenuItem>
              </NavigationMenuList>
            </NavigationMenu>
          </nav>
        </div>

        <div className="hidden md:flex items-center gap-4">
          <form onSubmit={handleSearch} className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search products..."
              className="w-[200px] lg:w-[300px] pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </form>

          <ThemeToggle />

          <Link href="/cart">
            <Button variant="outline" size="icon" className="relative">
              <ShoppingCart className="h-5 w-5" />
              <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-primary text-xs text-primary-foreground flex items-center justify-center">
                0
              </span>
            </Button>
          </Link>

          <Link href="/wishlist">
            <Button variant="outline" size="icon">
              <Heart className="h-5 w-5" />
            </Button>
          </Link>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon">
                <User className="h-5 w-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem asChild>
                <Link href="/dashboard">Dashboard</Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/dashboard/orders">Order History</Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/dashboard/profile">My Profile</Link>
              </DropdownMenuItem>
              {isAdmin && (
                <>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/admin">Admin Panel</Link>
                  </DropdownMenuItem>
                </>
              )}
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleSignOut}>
                <LogOut className="mr-2 h-4 w-4" />
                <span>Log out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        <div className="flex md:hidden items-center gap-4">
          <Link href="/cart">
            <Button variant="outline" size="icon" className="relative">
              <ShoppingCart className="h-5 w-5" />
              <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-primary text-xs text-primary-foreground flex items-center justify-center">
                0
              </span>
            </Button>
          </Link>

          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="overflow-y-auto">
              <div className="grid gap-6 py-6">
                <div className="space-y-3">
                  <form onSubmit={handleSearch} className="relative">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      type="search"
                      placeholder="Search products..."
                      className="pl-8"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </form>
                  <div className="flex items-center justify-between">
                    <ThemeToggle />
                    <Button variant="outline" onClick={handleSignOut}>
                      <LogOut className="mr-2 h-4 w-4" />
                      <span>Log out</span>
                    </Button>
                  </div>
                </div>
                <div className="grid gap-2">
                  <h3 className="text-sm font-medium">Shop</h3>
                  <Link href="/" className="flex items-center gap-2 py-2">
                    <Home className="h-4 w-4" />
                    <span>Home</span>
                  </Link>
                  <Link href="/products" className="flex items-center gap-2 py-2">
                    <Package className="h-4 w-4" />
                    <span>All Products</span>
                  </Link>
                  <Link href="/products?category=electronics" className="flex items-center gap-2 py-2 pl-4">
                    <span>Electronics</span>
                  </Link>
                  <Link href="/products?category=clothing" className="flex items-center gap-2 py-2 pl-4">
                    <span>Clothing</span>
                  </Link>
                  <Link href="/products?category=home-kitchen" className="flex items-center gap-2 py-2 pl-4">
                    <span>Home & Kitchen</span>
                  </Link>
                  <Link href="/products?deals=true" className="flex items-center gap-2 py-2">
                    <span>Deals</span>
                  </Link>

                  <h3 className="text-sm font-medium mt-4">Account</h3>
                  <Link href="/dashboard" className="flex items-center gap-2 py-2">
                    <User className="h-4 w-4" />
                    <span>Dashboard</span>
                  </Link>
                  <Link href="/dashboard/orders" className="flex items-center gap-2 py-2">
                    <Clock className="h-4 w-4" />
                    <span>Order History</span>
                  </Link>
                  <Link href="/dashboard/profile" className="flex items-center gap-2 py-2">
                    <User className="h-4 w-4" />
                    <span>My Profile</span>
                  </Link>
                  <Link href="/wishlist" className="flex items-center gap-2 py-2">
                    <Heart className="h-4 w-4" />
                    <span>Wishlist</span>
                  </Link>

                  <h3 className="text-sm font-medium mt-4">Help</h3>
                  <Link href="/contact" className="flex items-center gap-2 py-2">
                    <Phone className="h-4 w-4" />
                    <span>Contact Us</span>
                  </Link>
                  <Link href="/shipping" className="flex items-center gap-2 py-2">
                    <TruckIcon className="h-4 w-4" />
                    <span>Shipping Information</span>
                  </Link>
                  <Link href="/returns" className="flex items-center gap-2 py-2">
                    <RefreshCw className="h-4 w-4" />
                    <span>Returns & Exchanges</span>
                  </Link>
                  <Link href="/faq" className="flex items-center gap-2 py-2">
                    <HelpCircle className="h-4 w-4" />
                    <span>FAQ</span>
                  </Link>
                  <Link href="/privacy" className="flex items-center gap-2 py-2">
                    <FileText className="h-4 w-4" />
                    <span>Privacy Policy</span>
                  </Link>

                  {isAdmin && (
                    <>
                      <h3 className="text-sm font-medium mt-4">Admin</h3>
                      <Link href="/admin" className="flex items-center gap-2 py-2">
                        <Settings className="h-4 w-4" />
                        <span>Admin Panel</span>
                      </Link>
                    </>
                  )}
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}
