"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { motion } from "framer-motion"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Heart, ShoppingCart, Star } from "lucide-react"

// Mock data - would be fetched from API in a real app
const deals = [
  {
    id: 5,
    name: 'Ultra HD 4K Smart TV - 55"',
    price: 699.99,
    originalPrice: 999.99,
    rating: 4.7,
    image: "/placeholder.svg?height=300&width=300",
    category: "Electronics",
    discount: 30,
    endsIn: "2d 5h 30m",
  },
  {
    id: 6,
    name: "Professional Chef Knife Set",
    price: 89.99,
    originalPrice: 149.99,
    rating: 4.9,
    image: "/placeholder.svg?height=300&width=300",
    category: "Home & Kitchen",
    discount: 40,
    endsIn: "1d 12h 45m",
  },
  {
    id: 7,
    name: "Wireless Noise Cancelling Earbuds",
    price: 79.99,
    originalPrice: 129.99,
    rating: 4.5,
    image: "/placeholder.svg?height=300&width=300",
    category: "Electronics",
    discount: 38,
    endsIn: "3d 8h 15m",
  },
  {
    id: 8,
    name: "Premium Leather Wallet",
    price: 29.99,
    originalPrice: 49.99,
    rating: 4.6,
    image: "/placeholder.svg?height=300&width=300",
    category: "Accessories",
    discount: 40,
    endsIn: "5h 20m",
  },
]

export function TopDeals() {
  const [hoveredProduct, setHoveredProduct] = useState<number | null>(null)
  const [timeLeft, setTimeLeft] = useState<{ [key: number]: string }>(
    deals.reduce((acc, deal) => ({ ...acc, [deal.id]: deal.endsIn }), {}),
  )

  useEffect(() => {
    // This would be replaced with actual countdown logic in a real app
    const interval = setInterval(() => {
      // Simulate countdown
    }, 60000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
      {deals.map((product) => (
        <motion.div
          key={product.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          whileHover={{ y: -5 }}
        >
          <Card
            className="h-full overflow-hidden"
            onMouseEnter={() => setHoveredProduct(product.id)}
            onMouseLeave={() => setHoveredProduct(null)}
          >
            <div className="relative pt-4 px-4">
              <Badge variant="destructive" className="absolute top-6 right-6 z-10">
                {product.discount}% OFF
              </Badge>
              <div className="relative h-[200px] w-full mb-4 overflow-hidden rounded-md">
                <Image
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  fill
                  className="object-cover transition-transform duration-300 ease-in-out group-hover:scale-105"
                />
                {hoveredProduct === product.id && (
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                    <Link href={`/products/${product.id}`}>
                      <Button>Quick View</Button>
                    </Link>
                  </div>
                )}
              </div>
            </div>

            <CardContent className="p-4">
              <div className="text-sm text-muted-foreground mb-1">{product.category}</div>
              <Link href={`/products/${product.id}`} className="hover:underline">
                <h3 className="font-semibold text-lg line-clamp-2 mb-1">{product.name}</h3>
              </Link>
              <div className="flex items-center mb-2">
                {Array(5)
                  .fill(0)
                  .map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${
                        i < Math.floor(product.rating)
                          ? "text-yellow-400 fill-yellow-400"
                          : i < product.rating
                            ? "text-yellow-400 fill-yellow-400 opacity-50"
                            : "text-gray-300"
                      }`}
                    />
                  ))}
                <span className="text-xs text-muted-foreground ml-1">({product.rating})</span>
              </div>
              <div className="flex items-center">
                <span className="font-bold text-lg text-red-600">Rs {product.price.toFixed(2)}</span>
                <span className="text-muted-foreground line-through ml-2">Rs {product.originalPrice.toFixed(2)}</span>
              </div>
              <div className="mt-2 text-sm font-medium text-amber-600">Deal ends in: {timeLeft[product.id]}</div>
            </CardContent>

            <CardFooter className="p-4 pt-0 flex gap-2">
              <Button className="w-full" size="sm">
                <ShoppingCart className="mr-2 h-4 w-4" />
                Add to Cart
              </Button>
              <Button variant="outline" size="icon" className="shrink-0">
                <Heart className="h-4 w-4" />
                <span className="sr-only">Add to wishlist</span>
              </Button>
            </CardFooter>
          </Card>
        </motion.div>
      ))}
    </div>
  )
}
