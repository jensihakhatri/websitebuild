import Image from "next/image"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"

const categories = [
  {
    id: 1,
    name: "Electronics",
    image: "/placeholder.svg?height=200&width=200",
    itemCount: 120,
    slug: "electronics",
  },
  {
    id: 2,
    name: "Clothing",
    image: "/placeholder.svg?height=200&width=200",
    itemCount: 350,
    slug: "clothing",
  },
  {
    id: 3,
    name: "Home & Kitchen",
    image: "/placeholder.svg?height=200&width=200",
    itemCount: 210,
    slug: "home-kitchen",
  },
  {
    id: 4,
    name: "Beauty",
    image: "/placeholder.svg?height=200&width=200",
    itemCount: 180,
    slug: "beauty",
  },
]

export function CategoryHighlights() {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
      {categories.map((category) => (
        <Link key={category.id} href={`/category/${category.slug}`}>
          <Card className="overflow-hidden transition-all duration-200 hover:shadow-md">
            <div className="relative h-40 w-full">
              <Image src={category.image || "/placeholder.svg"} alt={category.name} fill className="object-cover" />
            </div>
            <CardContent className="p-4 text-center">
              <h3 className="font-semibold text-lg">{category.name}</h3>
              <p className="text-sm text-muted-foreground">{category.itemCount} Products</p>
            </CardContent>
          </Card>
        </Link>
      ))}
    </div>
  )
}
