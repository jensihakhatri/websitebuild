"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { motion } from "framer-motion"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Star, ShoppingCart, Heart } from "lucide-react"
import { supabase } from "@/lib/supabase-client"

export function FeaturedProducts() {
  const [products, setProducts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchFeaturedProducts() {
      const { data, error } = await supabase
        .from("products")
        .select(`
          id, 
          name, 
          slug,
          price, 
          discount_percentage, 
          is_new,
          rating,
          categories:categories(name),
          images:product_images(image_url, is_primary)
        `)
        .eq("is_featured", true)
        .limit(4)

      if (data) {
        setProducts(data)
      }
      setLoading(false)
    }

    fetchFeaturedProducts()
  }, [])

  if (loading) {
    return (
      <div className="py-12">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl font-bold">Featured Products</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="border rounded-lg p-4 h-[350px] animate-pulse">
                <div className="bg-gray-200 h-[180px] w-full rounded-md mb-4"></div>
                <div className="bg-gray-200 h-4 w-1/4 rounded mb-2"></div>
                <div className="bg-gray-200 h-6 w-3/4 rounded mb-4"></div>
                <div className="bg-gray-200 h-4 w-1/2 rounded mb-4"></div>
                <div className="bg-gray-200 h-10 w-full rounded"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="py-12">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-2xl font-bold">Featured Products</h2>
          <Link href="/products" className="text-primary hover:underline">
            View All
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              whileHover={{ y: -5 }}
            >
              <Card className="h-full overflow-hidden">
                <div className="relative pt-4 px-4">
                  {product.is_new && <Badge className="absolute top-6 left-6 z-10">New</Badge>}
                  {product.discount_percentage > 0 && (
                    <Badge variant="destructive" className="absolute top-6 right-6 z-10">
                      {product.discount_percentage}% OFF
                    </Badge>
                  )}
                  <Link href={`/products/${product.slug}`}>
                    <div className="relative h-[180px] w-full mb-4 overflow-hidden rounded-md group">
                      <Image
                        src={
                          product.images?.find((img: any) => img.is_primary)?.image_url ||
                          product.images?.[0]?.image_url ||
                          "/placeholder.svg?height=300&width=300" ||
                          "/placeholder.svg" ||
                          "/placeholder.svg"
                        }
                        alt={product.name}
                        fill
                        className="object-cover transition-transform duration-300 ease-in-out group-hover:scale-105"
                      />
                    </div>
                  </Link>
                </div>

                <CardContent className="p-4">
                  <div className="text-sm text-muted-foreground mb-1">{product.categories?.name}</div>
                  <Link href={`/products/${product.slug}`} className="hover:underline">
                    <h3 className="font-semibold text-lg line-clamp-2 mb-1">{product.name}</h3>
                  </Link>
                  <div className="flex items-center mb-2">
                    {Array(5)
                      .fill(0)
                      .map((_, i) => (
                        <Star
                          key={i}
                          className={`h-4 w-4 ${
                            i < Math.floor(product.rating)
                              ? "text-yellow-400 fill-yellow-400"
                              : i < product.rating
                                ? "text-yellow-400 fill-yellow-400 opacity-50"
                                : "text-gray-300"
                          }`}
                        />
                      ))}
                    <span className="text-xs text-muted-foreground ml-1">({product.rating})</span>
                  </div>
                  <div className="flex items-center">
                    {product.discount_percentage > 0 ? (
                      <>
                        <span className="font-bold text-lg">
                          Rs {(product.price * (1 - product.discount_percentage / 100)).toFixed(2)}
                        </span>
                        <span className="text-muted-foreground line-through ml-2">Rs {product.price.toFixed(2)}</span>
                      </>
                    ) : (
                      <span className="font-bold text-lg">Rs {product.price.toFixed(2)}</span>
                    )}
                  </div>
                </CardContent>

                <CardFooter className="p-4 pt-0 flex gap-2">
                  <Button className="w-full" size="sm">
                    <ShoppingCart className="mr-2 h-4 w-4" />
                    Add to Cart
                  </Button>
                  <Button variant="outline" size="icon" className="shrink-0">
                    <Heart className="h-4 w-4" />
                    <span className="sr-only">Add to wishlist</span>
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  )
}
