"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { cn } from "@/lib/utils"

const slides = [
  {
    id: 1,
    title: "Summer Collection 2023",
    description: "Discover the latest trends for the summer season",
    buttonText: "Shop Now",
    buttonLink: "/category/summer",
    image: "/placeholder.svg?height=600&width=1200",
  },
  {
    id: 2,
    title: "New Electronics Arrivals",
    description: "Check out our latest tech gadgets and accessories",
    buttonText: "Explore",
    buttonLink: "/category/electronics",
    image: "/placeholder.svg?height=600&width=1200",
  },
  {
    id: 3,
    title: "Home & Kitchen Essentials",
    description: "Transform your living space with our curated collection",
    buttonText: "Discover",
    buttonLink: "/category/home-kitchen",
    image: "/placeholder.svg?height=600&width=1200",
  },
]

export function HeroCarousel() {
  const [currentSlide, setCurrentSlide] = useState(0)

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev === slides.length - 1 ? 0 : prev + 1))
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev === 0 ? slides.length - 1 : prev - 1))
  }

  useEffect(() => {
    const interval = setInterval(() => {
      nextSlide()
    }, 5000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="relative overflow-hidden rounded-xl">
      <div
        className="flex transition-transform duration-500 ease-out"
        style={{ transform: `translateX(-${currentSlide * 100}%)` }}
      >
        {slides.map((slide) => (
          <div key={slide.id} className="min-w-full relative">
            <div className="relative h-[300px] md:h-[400px] lg:h-[500px] w-full">
              <Image src={slide.image || "/placeholder.svg"} alt={slide.title} fill className="object-cover" priority />
              <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-transparent flex flex-col justify-center px-6 md:px-12 lg:px-20">
                <h1 className="text-2xl md:text-4xl lg:text-5xl font-bold text-white mb-4">{slide.title}</h1>
                <p className="text-white/80 text-sm md:text-base lg:text-lg max-w-md mb-6">{slide.description}</p>
                <div>
                  <Link href={slide.buttonLink}>
                    <Button size="lg">{slide.buttonText}</Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <Button
        variant="outline"
        size="icon"
        className="absolute left-4 top-1/2 -translate-y-1/2 bg-background/80 hover:bg-background"
        onClick={prevSlide}
      >
        <ChevronLeft className="h-6 w-6" />
        <span className="sr-only">Previous slide</span>
      </Button>

      <Button
        variant="outline"
        size="icon"
        className="absolute right-4 top-1/2 -translate-y-1/2 bg-background/80 hover:bg-background"
        onClick={nextSlide}
      >
        <ChevronRight className="h-6 w-6" />
        <span className="sr-only">Next slide</span>
      </Button>

      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-2">
        {slides.map((_, index) => (
          <button
            key={index}
            className={cn(
              "w-2 h-2 rounded-full transition-all",
              currentSlide === index ? "bg-primary w-4" : "bg-primary/50",
            )}
            onClick={() => setCurrentSlide(index)}
          >
            <span className="sr-only">Go to slide {index + 1}</span>
          </button>
        ))}
      </div>
    </div>
  )
}
