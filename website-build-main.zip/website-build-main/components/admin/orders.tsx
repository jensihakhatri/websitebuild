"use client"

import { useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { AlertCircle, Clock, MoreHorizontal, Package, Search, Truck } from "lucide-react"

// Mock data
const orders = [
  {
    id: "ORD-1001",
    customer: "John Doe",
    email: "john.doe@example.com",
    date: "2023-05-15",
    total: 149.98,
    status: "Processing",
    items: [
      {
        id: 1,
        name: "Wireless Bluetooth Headphones",
        price: 129.99,
        quantity: 1,
        image: "/placeholder.svg?height=50&width=50",
      },
      {
        id: 3,
        name: "Premium Cotton T-Shirt",
        price: 24.99,
        quantity: 1,
        image: "/placeholder.svg?height=50&width=50",
      },
    ],
    isUrgent: true,
    urgentNote: "Please deliver before Friday for a birthday gift.",
    paymentMethod: "Cash on Delivery",
    shippingAddress: "123 Main St, Anytown, AN 12345",
  },
  {
    id: "ORD-1002",
    customer: "Jane Smith",
    email: "jane.smith@example.com",
    date: "2023-05-14",
    total: 199.99,
    status: "Shipped",
    items: [
      {
        id: 2,
        name: "Smart Watch Series 5",
        price: 199.99,
        quantity: 1,
        image: "/placeholder.svg?height=50&width=50",
      },
    ],
    isUrgent: false,
    urgentNote: "",
    paymentMethod: "Esewa",
    shippingAddress: "456 Oak Ave, Somewhere, SM 67890",
  },
  {
    id: "ORD-1003",
    customer: "Robert Johnson",
    email: "robert.johnson@example.com",
    date: "2023-05-13",
    total: 39.98,
    status: "Delivered",
    items: [
      {
        id: 4,
        name: "Stainless Steel Water Bottle",
        price: 19.99,
        quantity: 2,
        image: "/placeholder.svg?height=50&width=50",
      },
    ],
    isUrgent: false,
    urgentNote: "",
    paymentMethod: "Cash on Delivery",
    shippingAddress: "789 Pine Rd, Elsewhere, EL 10111",
  },
  {
    id: "ORD-1004",
    customer: "Emily Davis",
    email: "emily.davis@example.com",
    date: "2023-05-12",
    total: 699.99,
    status: "Processing",
    items: [
      {
        id: 5,
        name: 'Ultra HD 4K Smart TV - 55"',
        price: 699.99,
        quantity: 1,
        image: "/placeholder.svg?height=50&width=50",
      },
    ],
    isUrgent: true,
    urgentNote: "Need it for moving into new apartment this weekend.",
    paymentMethod: "Esewa",
    shippingAddress: "321 Elm St, Nowhere, NW 54321",
  },
  {
    id: "ORD-1005",
    customer: "Michael Wilson",
    email: "michael.wilson@example.com",
    date: "2023-05-11",
    total: 224.97,
    status: "Delivered",
    items: [
      {
        id: 3,
        name: "Premium Cotton T-Shirt",
        price: 24.99,
        quantity: 3,
        image: "/placeholder.svg?height=50&width=50",
      },
      {
        id: 4,
        name: "Stainless Steel Water Bottle",
        price: 19.99,
        quantity: 1,
        image: "/placeholder.svg?height=50&width=50",
      },
      {
        id: 8,
        name: "Premium Leather Wallet",
        price: 29.99,
        quantity: 1,
        image: "/placeholder.svg?height=50&width=50",
      },
    ],
    isUrgent: false,
    urgentNote: "",
    paymentMethod: "Cash on Delivery",
    shippingAddress: "555 Maple Dr, Anyplace, AP 13579",
  },
]

export function AdminOrders() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedStatus, setSelectedStatus] = useState("all")
  const [isViewOrderOpen, setIsViewOrderOpen] = useState(false)
  const [selectedOrder, setSelectedOrder] = useState<any>(null)

  // Filter orders based on search query and status
  const filteredOrders = orders.filter((order) => {
    const matchesSearch =
      order.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.customer.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.email.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesStatus = selectedStatus === "all" || order.status.toLowerCase() === selectedStatus.toLowerCase()

    return matchesSearch && matchesStatus
  })

  // Get urgent orders
  const urgentOrders = orders.filter((order) => order.isUrgent && order.status !== "Delivered")

  const handleViewOrder = (order: any) => {
    setSelectedOrder(order)
    setIsViewOrderOpen(true)
  }

  const getStatusIcon = (status: string) => {
    switch (status.toLowerCase()) {
      case "processing":
        return <Clock className="h-4 w-4 text-blue-500" />
      case "shipped":
        return <Truck className="h-4 w-4 text-yellow-500" />
      case "delivered":
        return <Package className="h-4 w-4 text-green-500" />
      default:
        return null
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case "processing":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            Processing
          </Badge>
        )
      case "shipped":
        return (
          <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
            Shipped
          </Badge>
        )
      case "delivered":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Delivered
          </Badge>
        )
      default:
        return <Badge variant="outline">Unknown</Badge>
    }
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="all">
        <TabsList>
          <TabsTrigger value="all">All Orders</TabsTrigger>
          <TabsTrigger value="urgent" className="relative">
            Urgent Orders
            {urgentOrders.length > 0 && (
              <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-red-500 text-xs text-white flex items-center justify-center">
                {urgentOrders.length}
              </span>
            )}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-6">
          <div className="flex flex-col sm:flex-row gap-4 justify-between">
            <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
              <div className="relative w-full sm:w-[300px]">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search by order ID or customer..."
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>

              <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                <SelectTrigger className="w-full sm:w-[180px]">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="processing">Processing</SelectItem>
                  <SelectItem value="shipped">Shipped</SelectItem>
                  <SelectItem value="delivered">Delivered</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Order ID</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Total</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredOrders.map((order) => (
                  <TableRow key={order.id}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        {order.id}
                        {order.isUrgent && <AlertCircle className="h-4 w-4 text-red-500" title="Urgent Order" />}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div>{order.customer}</div>
                        <div className="text-sm text-muted-foreground">{order.email}</div>
                      </div>
                    </TableCell>
                    <TableCell>{new Date(order.date).toLocaleDateString()}</TableCell>
                    <TableCell>Rs {order.total.toFixed(2)}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {getStatusIcon(order.status)}
                        {getStatusBadge(order.status)}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">Actions</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleViewOrder(order)}>View Details</DropdownMenuItem>
                          <DropdownMenuItem>Update Status</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        <TabsContent value="urgent" className="space-y-6">
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Order ID</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Total</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Urgent Note</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {urgentOrders.map((order) => (
                  <TableRow key={order.id}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        {order.id}
                        <AlertCircle className="h-4 w-4 text-red-500" title="Urgent Order" />
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div>{order.customer}</div>
                        <div className="text-sm text-muted-foreground">{order.email}</div>
                      </div>
                    </TableCell>
                    <TableCell>{new Date(order.date).toLocaleDateString()}</TableCell>
                    <TableCell>Rs {order.total.toFixed(2)}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {getStatusIcon(order.status)}
                        {getStatusBadge(order.status)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="max-w-[200px] truncate" title={order.urgentNote}>
                        {order.urgentNote}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">Actions</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleViewOrder(order)}>View Details</DropdownMenuItem>
                          <DropdownMenuItem>Update Status</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}

                {urgentOrders.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-6">
                      <div className="flex flex-col items-center justify-center text-muted-foreground">
                        <Package className="h-10 w-10 mb-2" />
                        <p>No urgent orders at the moment</p>
                      </div>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
      </Tabs>

      {/* View Order Dialog */}
      <Dialog open={isViewOrderOpen} onOpenChange={setIsViewOrderOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Order Details</DialogTitle>
            <DialogDescription>Complete information about the order.</DialogDescription>
          </DialogHeader>

          {selectedOrder && (
            <div className="space-y-6">
              <div className="flex flex-col md:flex-row justify-between gap-4">
                <div>
                  <h3 className="font-semibold text-lg flex items-center gap-2">
                    {selectedOrder.id}
                    {selectedOrder.isUrgent && <Badge variant="destructive">Urgent</Badge>}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Placed on {new Date(selectedOrder.date).toLocaleDateString()}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  {getStatusBadge(selectedOrder.status)}
                  <Select defaultValue={selectedOrder.status.toLowerCase()}>
                    <SelectTrigger className="w-[180px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="processing">Processing</SelectItem>
                      <SelectItem value="shipped">Shipped</SelectItem>
                      <SelectItem value="delivered">Delivered</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button size="sm">Update</Button>
                </div>
              </div>

              {selectedOrder.isUrgent && selectedOrder.urgentNote && (
                <div className="bg-red-50 border border-red-200 rounded-md p-3">
                  <div className="flex items-start gap-2">
                    <AlertCircle className="h-5 w-5 text-red-500 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-red-700">Urgent Order Note</h4>
                      <p className="text-sm text-red-600">{selectedOrder.urgentNote}</p>
                    </div>
                  </div>
                </div>
              )}

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium mb-2">Customer Information</h4>
                  <div className="space-y-1 text-sm">
                    <p className="font-medium">{selectedOrder.customer}</p>
                    <p>{selectedOrder.email}</p>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Shipping Address</h4>
                  <p className="text-sm">{selectedOrder.shippingAddress}</p>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Payment Method</h4>
                  <p className="text-sm">{selectedOrder.paymentMethod}</p>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Order Summary</h4>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span>Subtotal:</span>
                      <span>Rs {selectedOrder.total.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Shipping:</span>
                      <span>$0.00</span>
                    </div>
                    <div className="flex justify-between font-medium">
                      <span>Total:</span>
                      <span>Rs {selectedOrder.total.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-2">Order Items</h4>
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Product</TableHead>
                        <TableHead>Price</TableHead>
                        <TableHead>Quantity</TableHead>
                        <TableHead className="text-right">Total</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {selectedOrder.items.map((item: any) => (
                        <TableRow key={item.id}>
                          <TableCell>
                            <div className="flex items-center gap-3">
                              <div className="h-10 w-10 relative rounded overflow-hidden">
                                <Image
                                  src={item.image || "/placeholder.svg"}
                                  alt={item.name}
                                  fill
                                  className="object-cover"
                                />
                              </div>
                              <div className="font-medium">{item.name}</div>
                            </div>
                          </TableCell>
                          <TableCell>Rs {item.price.toFixed(2)}</TableCell>
                          <TableCell>{item.quantity}</TableCell>
                          <TableCell className="text-right">Rs {(item.price * item.quantity).toFixed(2)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsViewOrderOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
