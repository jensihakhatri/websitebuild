"use client"

import { useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Switch } from "@/components/ui/switch"
import { Upload } from "lucide-react"
import { changeAdminPassword } from "@/app/actions/admin-actions"
import { useToast } from "@/components/ui/use-toast"

export function AdminSettings() {
  const { toast } = useToast()
  const [isChangingPassword, setIsChangingPassword] = useState(false)

  const [banners, setBanners] = useState([
    {
      id: 1,
      title: "Summer Collection 2023",
      description: "Discover the latest trends for the summer season",
      buttonText: "Shop Now",
      buttonLink: "/category/summer",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: 2,
      title: "New Electronics Arrivals",
      description: "Check out our latest tech gadgets and accessories",
      buttonText: "Explore",
      buttonLink: "/category/electronics",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: 3,
      title: "Home & Kitchen Essentials",
      description: "Transform your living space with our curated collection",
      buttonText: "Discover",
      buttonLink: "/category/home-kitchen",
      image: "/placeholder.svg?height=200&width=400",
    },
  ])

  const [socialLinks, setSocialLinks] = useState({
    facebook: "https://facebook.com/nextcommerce",
    instagram: "https://instagram.com/nextcommerce",
    twitter: "https://twitter.com/nextcommerce",
    whatsapp: "+1234567890",
  })

  const [contactInfo, setContactInfo] = useState({
    email: "support@nextcommerce.com",
    phone: "+1234567890",
    address: "123 Commerce St, Business City, BC 12345",
    hours: "Monday-Friday: 9am-5pm, Saturday: 10am-4pm, Sunday: Closed",
  })

  const [siteSettings, setSiteSettings] = useState({
    siteName: "NextCommerce",
    siteDescription: "Your one-stop shop for all your shopping needs",
    logo: "/placeholder.svg?height=100&width=100",
    favicon: "/placeholder.svg?height=32&width=32",
    enableDarkMode: true,
    enableWishlist: true,
    enableRecentlyViewed: true,
    enableSearchAutocomplete: true,
  })

  async function handlePasswordChange(formData: FormData) {
    setIsChangingPassword(true)

    try {
      const result = await changeAdminPassword(formData)

      if (result.success) {
        toast({
          title: "Success",
          description: result.message,
        })

        // Reset form
        const form = document.getElementById("password-form") as HTMLFormElement
        form?.reset()
      } else {
        toast({
          title: "Error",
          description: result.message,
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An unexpected error occurred",
        variant: "destructive",
      })
    } finally {
      setIsChangingPassword(false)
    }
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="general">
        <TabsList className="w-full justify-start">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="homepage">Homepage</TabsTrigger>
          <TabsTrigger value="social">Social Media</TabsTrigger>
          <TabsTrigger value="contact">Contact Info</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Site Information</CardTitle>
              <CardDescription>Basic information about your eCommerce store.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="siteName">Site Name</Label>
                  <Input
                    id="siteName"
                    value={siteSettings.siteName}
                    onChange={(e) => setSiteSettings({ ...siteSettings, siteName: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="siteDescription">Site Description</Label>
                  <Input
                    id="siteDescription"
                    value={siteSettings.siteDescription}
                    onChange={(e) => setSiteSettings({ ...siteSettings, siteDescription: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label>Logo</Label>
                  <div className="flex items-center gap-4">
                    <div className="h-16 w-16 relative rounded overflow-hidden border">
                      <Image
                        src={siteSettings.logo || "/placeholder.svg"}
                        alt="Site Logo"
                        fill
                        className="object-contain"
                      />
                    </div>
                    <Button variant="outline" size="sm">
                      <Upload className="h-4 w-4 mr-2" />
                      Change Logo
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Favicon</Label>
                  <div className="flex items-center gap-4">
                    <div className="h-8 w-8 relative rounded overflow-hidden border">
                      <Image
                        src={siteSettings.favicon || "/placeholder.svg"}
                        alt="Favicon"
                        fill
                        className="object-contain"
                      />
                    </div>
                    <Button variant="outline" size="sm">
                      <Upload className="h-4 w-4 mr-2" />
                      Change Favicon
                    </Button>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h3 className="font-medium">Features</h3>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="darkMode" className="block">
                      Dark Mode
                    </Label>
                    <p className="text-sm text-muted-foreground">Allow users to switch between light and dark themes</p>
                  </div>
                  <Switch
                    id="darkMode"
                    checked={siteSettings.enableDarkMode}
                    onCheckedChange={(checked) => setSiteSettings({ ...siteSettings, enableDarkMode: checked })}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="wishlist" className="block">
                      Wishlist
                    </Label>
                    <p className="text-sm text-muted-foreground">Allow users to save products to their wishlist</p>
                  </div>
                  <Switch
                    id="wishlist"
                    checked={siteSettings.enableWishlist}
                    onCheckedChange={(checked) => setSiteSettings({ ...siteSettings, enableWishlist: checked })}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="recentlyViewed" className="block">
                      Recently Viewed
                    </Label>
                    <p className="text-sm text-muted-foreground">Show users their recently viewed products</p>
                  </div>
                  <Switch
                    id="recentlyViewed"
                    checked={siteSettings.enableRecentlyViewed}
                    onCheckedChange={(checked) => setSiteSettings({ ...siteSettings, enableRecentlyViewed: checked })}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="searchAutocomplete" className="block">
                      Search Autocomplete
                    </Label>
                    <p className="text-sm text-muted-foreground">
                      Show search suggestions as users type in the search box
                    </p>
                  </div>
                  <Switch
                    id="searchAutocomplete"
                    checked={siteSettings.enableSearchAutocomplete}
                    onCheckedChange={(checked) =>
                      setSiteSettings({ ...siteSettings, enableSearchAutocomplete: checked })
                    }
                  />
                </div>
              </div>

              <div className="flex justify-end">
                <Button>Save Settings</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="homepage" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Homepage Banners</CardTitle>
              <CardDescription>Manage the banners that appear in the homepage carousel.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {banners.map((banner, index) => (
                <div key={banner.id} className="border rounded-md p-4 space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="font-medium">Banner {index + 1}</h3>
                    <Button variant="outline" size="sm">
                      Remove
                    </Button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor={`banner-title-${banner.id}`}>Title</Label>
                      <Input id={`banner-title-${banner.id}`} value={banner.title} />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor={`banner-description-${banner.id}`}>Description</Label>
                      <Input id={`banner-description-${banner.id}`} value={banner.description} />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor={`banner-button-text-${banner.id}`}>Button Text</Label>
                      <Input id={`banner-button-text-${banner.id}`} value={banner.buttonText} />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor={`banner-button-link-${banner.id}`}>Button Link</Label>
                      <Input id={`banner-button-link-${banner.id}`} value={banner.buttonLink} />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Banner Image</Label>
                    <div className="flex items-center gap-4">
                      <div className="h-24 w-48 relative rounded overflow-hidden border">
                        <Image
                          src={banner.image || "/placeholder.svg"}
                          alt={banner.title}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <Button variant="outline" size="sm">
                        <Upload className="h-4 w-4 mr-2" />
                        Change Image
                      </Button>
                    </div>
                  </div>
                </div>
              ))}

              <Button className="w-full">Add New Banner</Button>

              <div className="flex justify-end">
                <Button>Save Changes</Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Featured Sections</CardTitle>
              <CardDescription>Configure which sections appear on the homepage and their order.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between border p-3 rounded-md">
                  <div className="font-medium">Hero Carousel</div>
                  <Switch defaultChecked />
                </div>

                <div className="flex items-center justify-between border p-3 rounded-md">
                  <div className="font-medium">Featured Products</div>
                  <Switch defaultChecked />
                </div>

                <div className="flex items-center justify-between border p-3 rounded-md">
                  <div className="font-medium">Category Highlights</div>
                  <Switch defaultChecked />
                </div>

                <div className="flex items-center justify-between border p-3 rounded-md">
                  <div className="font-medium">Top Deals</div>
                  <Switch defaultChecked />
                </div>

                <div className="flex items-center justify-between border p-3 rounded-md">
                  <div className="font-medium">New Arrivals</div>
                  <Switch />
                </div>

                <div className="flex items-center justify-between border p-3 rounded-md">
                  <div className="font-medium">Testimonials</div>
                  <Switch />
                </div>
              </div>

              <div className="flex justify-end">
                <Button>Save Changes</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="social" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Social Media Links</CardTitle>
              <CardDescription>Configure your store's social media profiles.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="facebook">Facebook</Label>
                  <Input
                    id="facebook"
                    value={socialLinks.facebook}
                    onChange={(e) => setSocialLinks({ ...socialLinks, facebook: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="instagram">Instagram</Label>
                  <Input
                    id="instagram"
                    value={socialLinks.instagram}
                    onChange={(e) => setSocialLinks({ ...socialLinks, instagram: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="twitter">Twitter</Label>
                  <Input
                    id="twitter"
                    value={socialLinks.twitter}
                    onChange={(e) => setSocialLinks({ ...socialLinks, twitter: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="whatsapp">WhatsApp Number</Label>
                  <Input
                    id="whatsapp"
                    value={socialLinks.whatsapp}
                    onChange={(e) => setSocialLinks({ ...socialLinks, whatsapp: e.target.value })}
                  />
                </div>
              </div>

              <div className="flex justify-end">
                <Button>Save Changes</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="contact" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Contact Information</CardTitle>
              <CardDescription>Configure your store's contact details.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    value={contactInfo.email}
                    onChange={(e) => setContactInfo({ ...contactInfo, email: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    value={contactInfo.phone}
                    onChange={(e) => setContactInfo({ ...contactInfo, phone: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="address">Address</Label>
                <Textarea
                  id="address"
                  value={contactInfo.address}
                  onChange={(e) => setContactInfo({ ...contactInfo, address: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="hours">Business Hours</Label>
                <Textarea
                  id="hours"
                  value={contactInfo.hours}
                  onChange={(e) => setContactInfo({ ...contactInfo, hours: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label>Google Maps Embed</Label>
                <div className="border rounded-md p-4 h-[300px] flex items-center justify-center bg-muted">
                  <p className="text-muted-foreground">Google Maps Embed Preview</p>
                </div>
                <Input placeholder="Paste your Google Maps embed code here" />
              </div>

              <div className="flex justify-end">
                <Button>Save Changes</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Change Admin Password</CardTitle>
              <CardDescription>Update your admin account password</CardDescription>
            </CardHeader>
            <CardContent>
              <form id="password-form" action={handlePasswordChange} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="currentPassword">Current Password</Label>
                  <Input id="currentPassword" name="currentPassword" type="password" required />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="newPassword">New Password</Label>
                  <Input id="newPassword" name="newPassword" type="password" required />
                  <p className="text-sm text-muted-foreground">Password must be at least 8 characters long</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Confirm New Password</Label>
                  <Input id="confirmPassword" name="confirmPassword" type="password" required />
                </div>

                <Button type="submit" disabled={isChangingPassword}>
                  {isChangingPassword ? "Changing Password..." : "Change Password"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
