"use client"

import { useState, useEffect } from "react"
import {
  BarChart3,
  ShoppingCart,
  Users,
  Package,
  TrendingUp,
  TrendingDown,
  AlertCircle,
  CheckCircle2,
  Clock,
  RefreshCw,
  Shield,
  Database,
  Zap,
  Cpu,
} from "lucide-react"
import { supabase } from "@/lib/supabase-client"

export function AdminDashboard() {
  const [stats, setStats] = useState({
    totalRevenue: 0,
    totalOrders: 0,
    totalProducts: 0,
    totalUsers: 0,
    pendingOrders: 0,
    lowStockProducts: 0,
    systemLoad: Math.floor(Math.random() * 100),
    memoryUsage: Math.floor(Math.random() * 100),
    diskUsage: Math.floor(Math.random() * 100),
    networkUsage: Math.floor(Math.random() * 100),
  })

  const [recentOrders, setRecentOrders] = useState<any[]>([])
  const [recentUsers, setRecentUsers] = useState<any[]>([])
  const [alerts, setAlerts] = useState<any[]>([
    {
      id: 1,
      type: "warning",
      message: "Low stock alert: 5 products below threshold",
      time: "14:32:12",
    },
    {
      id: 2,
      type: "info",
      message: "System update available: v2.4.5",
      time: "09:12:45",
    },
    {
      id: 3,
      type: "success",
      message: "Backup completed successfully",
      time: "04:30:00",
    },
  ])

  useEffect(() => {
    async function fetchDashboardData() {
      try {
        // Fetch stats
        const { count: productsCount } = await supabase.from("products").select("*", { count: "exact", head: true })

        const { count: ordersCount } = await supabase.from("orders").select("*", { count: "exact", head: true })

        const { count: usersCount } = await supabase.from("users").select("*", { count: "exact", head: true })

        const { count: pendingOrdersCount } = await supabase
          .from("orders")
          .select("*", { count: "exact", head: true })
          .eq("status", "processing")

        const { count: lowStockCount } = await supabase
          .from("products")
          .select("*", { count: "exact", head: true })
          .lt("stock", 10)

        // Calculate total revenue
        const { data: orders } = await supabase.from("orders").select("total_amount")

        const totalRevenue = orders?.reduce((sum, order) => sum + Number.parseFloat(order.total_amount), 0) || 0

        // Fetch recent orders
        const { data: recentOrdersData } = await supabase
          .from("orders")
          .select(`
            id,
            order_number,
            status,
            total_amount,
            created_at,
            user:users(email)
          `)
          .order("created_at", { ascending: false })
          .limit(5)

        // Fetch recent users
        const { data: recentUsersData } = await supabase
          .from("users")
          .select("*")
          .order("created_at", { ascending: false })
          .limit(5)

        setStats({
          totalRevenue,
          totalOrders: ordersCount || 0,
          totalProducts: productsCount || 0,
          totalUsers: usersCount || 0,
          pendingOrders: pendingOrdersCount || 0,
          lowStockProducts: lowStockCount || 0,
          systemLoad: Math.floor(Math.random() * 100),
          memoryUsage: Math.floor(Math.random() * 100),
          diskUsage: Math.floor(Math.random() * 100),
          networkUsage: Math.floor(Math.random() * 100),
        })

        if (recentOrdersData) setRecentOrders(recentOrdersData)
        if (recentUsersData) setRecentUsers(recentUsersData)
      } catch (error) {
        console.error("Error fetching dashboard data:", error)
      }
    }

    fetchDashboardData()
  }, [])

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Dashboard Overview</h2>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <RefreshCw className="h-4 w-4" />
          <span>Last updated: {new Date().toLocaleTimeString()}</span>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="admin-stat-card p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-muted-foreground">Total Revenue</p>
              <h3 className="text-2xl font-bold mt-1">Rs {stats.totalRevenue.toLocaleString()}</h3>
              <div className="flex items-center gap-1 mt-2 text-success text-sm">
                <TrendingUp className="h-4 w-4" />
                <span>+12.5%</span>
              </div>
            </div>
            <div className="admin-icon-container">
              <BarChart3 className="h-5 w-5" />
            </div>
          </div>
        </div>

        <div className="admin-stat-card p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-muted-foreground">Total Orders</p>
              <h3 className="text-2xl font-bold mt-1">{stats.totalOrders}</h3>
              <div className="flex items-center gap-1 mt-2 text-success text-sm">
                <TrendingUp className="h-4 w-4" />
                <span>+8.2%</span>
              </div>
            </div>
            <div className="admin-icon-container">
              <ShoppingCart className="h-5 w-5" />
            </div>
          </div>
        </div>

        <div className="admin-stat-card p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-muted-foreground">Total Products</p>
              <h3 className="text-2xl font-bold mt-1">{stats.totalProducts}</h3>
              <div className="flex items-center gap-1 mt-2 text-warning text-sm">
                <TrendingDown className="h-4 w-4" />
                <span>-2.4%</span>
              </div>
            </div>
            <div className="admin-icon-container">
              <Package className="h-5 w-5" />
            </div>
          </div>
        </div>

        <div className="admin-stat-card p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-muted-foreground">Total Users</p>
              <h3 className="text-2xl font-bold mt-1">{stats.totalUsers}</h3>
              <div className="flex items-center gap-1 mt-2 text-success text-sm">
                <TrendingUp className="h-4 w-4" />
                <span>+5.7%</span>
              </div>
            </div>
            <div className="admin-icon-container">
              <Users className="h-5 w-5" />
            </div>
          </div>
        </div>
      </div>

      {/* System Status */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="admin-card p-6">
          <h3 className="text-lg font-semibold mb-4">System Status</h3>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-muted-foreground">CPU Load</span>
                <span className="font-medium">{stats.systemLoad}%</span>
              </div>
              <div className="admin-progress-bar">
                <div
                  className={`${
                    stats.systemLoad > 80
                      ? "admin-progress-bar-fill-destructive"
                      : stats.systemLoad > 60
                        ? "admin-progress-bar-fill-warning"
                        : "admin-progress-bar-fill-success"
                  }`}
                  style={{ width: `${stats.systemLoad}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between mb-2">
                <span className="text-muted-foreground">Memory Usage</span>
                <span className="font-medium">{stats.memoryUsage}%</span>
              </div>
              <div className="admin-progress-bar">
                <div
                  className={`${
                    stats.memoryUsage > 80
                      ? "admin-progress-bar-fill-destructive"
                      : stats.memoryUsage > 60
                        ? "admin-progress-bar-fill-warning"
                        : "admin-progress-bar-fill-primary"
                  }`}
                  style={{ width: `${stats.memoryUsage}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between mb-2">
                <span className="text-muted-foreground">Disk Usage</span>
                <span className="font-medium">{stats.diskUsage}%</span>
              </div>
              <div className="admin-progress-bar">
                <div
                  className={`${
                    stats.diskUsage > 80
                      ? "admin-progress-bar-fill-destructive"
                      : stats.diskUsage > 60
                        ? "admin-progress-bar-fill-warning"
                        : "admin-progress-bar-fill-info"
                  }`}
                  style={{ width: `${stats.diskUsage}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between mb-2">
                <span className="text-muted-foreground">Network Usage</span>
                <span className="font-medium">{stats.networkUsage}%</span>
              </div>
              <div className="admin-progress-bar">
                <div className="admin-progress-bar-fill-primary" style={{ width: `${stats.networkUsage}%` }} />
              </div>
            </div>
          </div>
        </div>

        <div className="admin-card p-6">
          <h3 className="text-lg font-semibold mb-4">System Alerts</h3>
          <div className="space-y-3">
            {alerts.map((alert) => (
              <div key={alert.id} className="flex items-start gap-3 p-3 rounded-md bg-secondary/50">
                {alert.type === "warning" && <AlertCircle className="h-5 w-5 text-warning mt-0.5" />}
                {alert.type === "success" && <CheckCircle2 className="h-5 w-5 text-success mt-0.5" />}
                {alert.type === "info" && <Clock className="h-5 w-5 text-info mt-0.5" />}
                <div className="flex-1">
                  <p className="text-sm">{alert.message}</p>
                  <p className="text-xs text-muted-foreground mt-1">{alert.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="admin-card p-6">
        <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="admin-quick-action">
            <div className="admin-icon-container mb-2">
              <Package className="h-5 w-5" />
            </div>
            <span className="text-sm font-medium">Add Product</span>
          </div>
          <div className="admin-quick-action">
            <div className="admin-icon-container mb-2">
              <Users className="h-5 w-5" />
            </div>
            <span className="text-sm font-medium">Manage Users</span>
          </div>
          <div className="admin-quick-action">
            <div className="admin-icon-container mb-2">
              <Shield className="h-5 w-5" />
            </div>
            <span className="text-sm font-medium">Security Scan</span>
          </div>
          <div className="admin-quick-action">
            <div className="admin-icon-container mb-2">
              <Database className="h-5 w-5" />
            </div>
            <span className="text-sm font-medium">Backup Data</span>
          </div>
        </div>
      </div>

      {/* Recent Orders and Users */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="admin-card p-6">
          <h3 className="text-lg font-semibold mb-4">Recent Orders</h3>
          <div className="space-y-4">
            {recentOrders.length > 0 ? (
              recentOrders.map((order) => (
                <div key={order.id} className="flex items-center justify-between p-3 rounded-md bg-secondary/50">
                  <div>
                    <p className="font-medium">{order.order_number}</p>
                    <p className="text-sm text-muted-foreground">{order.user?.email}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">Rs {Number.parseFloat(order.total_amount).toLocaleString()}</p>
                    <span
                      className={`inline-block px-2 py-1 text-xs rounded-full ${
                        order.status === "processing"
                          ? "bg-blue-100/10 text-blue-500"
                          : order.status === "shipped"
                            ? "bg-yellow-100/10 text-yellow-500"
                            : "bg-green-100/10 text-green-500"
                      }`}
                    >
                      {order.status}
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-6 text-muted-foreground">
                <ShoppingCart className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No recent orders</p>
              </div>
            )}
          </div>
        </div>

        <div className="admin-card p-6">
          <h3 className="text-lg font-semibold mb-4">Recent Users</h3>
          <div className="space-y-4">
            {recentUsers.length > 0 ? (
              recentUsers.map((user) => (
                <div key={user.id} className="flex items-center justify-between p-3 rounded-md bg-secondary/50">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-medium">
                      {user.display_name ? user.display_name.charAt(0) : user.email.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <p className="font-medium">{user.display_name || "User"}</p>
                      <p className="text-sm text-muted-foreground">{user.email}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground">{new Date(user.created_at).toLocaleDateString()}</p>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-6 text-muted-foreground">
                <Users className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No recent users</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Resource Allocation */}
      <div className="admin-card p-6">
        <h3 className="text-lg font-semibold mb-4">Resource Allocation</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <div className="flex justify-between mb-2">
              <span className="text-muted-foreground">Processing Power</span>
              <span className="text-primary">42% allocated</span>
            </div>
            <div className="admin-progress-bar mb-4">
              <div className="admin-progress-bar-fill-primary" style={{ width: "42%" }} />
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Cpu className="h-4 w-4 text-muted-foreground" />
              <span className="text-muted-foreground">3.5 GHz | 12 Cores</span>
            </div>
          </div>

          <div>
            <div className="flex justify-between mb-2">
              <span className="text-muted-foreground">Memory Allocation</span>
              <span className="text-primary">68% allocated</span>
            </div>
            <div className="admin-progress-bar mb-4">
              <div className="admin-progress-bar-fill-primary" style={{ width: "68%" }} />
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Zap className="h-4 w-4 text-muted-foreground" />
              <span className="text-muted-foreground">16.4 GB / 24 GB</span>
            </div>
          </div>

          <div>
            <div className="flex justify-between mb-2">
              <span className="text-muted-foreground">Network Bandwidth</span>
              <span className="text-primary">35% allocated</span>
            </div>
            <div className="admin-progress-bar mb-4">
              <div className="admin-progress-bar-fill-primary" style={{ width: "35%" }} />
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Zap className="h-4 w-4 text-muted-foreground" />
              <span className="text-muted-foreground">1.2 GB/s | 42ms</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
