"use client"

import { useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MoreHorizontal, Search, ShoppingBag, User } from "lucide-react"

// Mock data
const users = [
  {
    id: "USR-1001",
    name: "John Doe",
    email: "john.doe@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    role: "customer",
    status: "active",
    joinDate: "2023-01-15",
    orders: 5,
    totalSpent: 349.95,
  },
  {
    id: "USR-1002",
    name: "Jane Smith",
    email: "jane.smith@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    role: "customer",
    status: "active",
    joinDate: "2023-02-20",
    orders: 3,
    totalSpent: 199.99,
  },
  {
    id: "USR-1003",
    name: "Robert Johnson",
    email: "robert.johnson@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    role: "customer",
    status: "inactive",
    joinDate: "2023-03-10",
    orders: 1,
    totalSpent: 39.98,
  },
  {
    id: "USR-1004",
    name: "Emily Davis",
    email: "emily.davis@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    role: "customer",
    status: "active",
    joinDate: "2023-04-05",
    orders: 2,
    totalSpent: 699.99,
  },
  {
    id: "USR-1005",
    name: "Michael Wilson",
    email: "michael.wilson@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    role: "admin",
    status: "active",
    joinDate: "2023-01-01",
    orders: 0,
    totalSpent: 0,
  },
]

export function AdminUsers() {
  const [searchQuery, setSearchQuery] = useState("")
  const [isViewUserOpen, setIsViewUserOpen] = useState(false)
  const [selectedUser, setSelectedUser] = useState<any>(null)

  // Filter users based on search query
  const filteredUsers = users.filter((user) => {
    return (
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.id.toLowerCase().includes(searchQuery.toLowerCase())
    )
  })

  const handleViewUser = (user: any) => {
    setSelectedUser(user)
    setIsViewUserOpen(true)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row gap-4 justify-between">
        <div className="relative w-full sm:w-[300px]">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search users..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>User</TableHead>
              <TableHead>Role</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Join Date</TableHead>
              <TableHead>Orders</TableHead>
              <TableHead>Total Spent</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredUsers.map((user) => (
              <TableRow key={user.id}>
                <TableCell>
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 relative rounded-full overflow-hidden">
                      <Image src={user.avatar || "/placeholder.svg"} alt={user.name} fill className="object-cover" />
                    </div>
                    <div>
                      <div className="font-medium">{user.name}</div>
                      <div className="text-sm text-muted-foreground">{user.email}</div>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  {user.role === "admin" ? <Badge>Admin</Badge> : <Badge variant="outline">Customer</Badge>}
                </TableCell>
                <TableCell>
                  {user.status === "active" ? (
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                      Active
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">
                      Inactive
                    </Badge>
                  )}
                </TableCell>
                <TableCell>{new Date(user.joinDate).toLocaleDateString()}</TableCell>
                <TableCell>{user.orders}</TableCell>
                <TableCell>${user.totalSpent.toFixed(2)}</TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                        <span className="sr-only">Actions</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => handleViewUser(user)}>View Details</DropdownMenuItem>
                      {user.status === "active" ? (
                        <DropdownMenuItem>Deactivate User</DropdownMenuItem>
                      ) : (
                        <DropdownMenuItem>Activate User</DropdownMenuItem>
                      )}
                      {user.role === "customer" ? (
                        <DropdownMenuItem>Make Admin</DropdownMenuItem>
                      ) : (
                        <DropdownMenuItem>Remove Admin</DropdownMenuItem>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* View User Dialog */}
      <Dialog open={isViewUserOpen} onOpenChange={setIsViewUserOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>User Details</DialogTitle>
            <DialogDescription>Complete information about the user.</DialogDescription>
          </DialogHeader>

          {selectedUser && (
            <div className="space-y-6">
              <div className="flex flex-col md:flex-row gap-6">
                <div className="flex flex-col items-center md:items-start gap-4">
                  <div className="h-24 w-24 relative rounded-full overflow-hidden">
                    <Image
                      src={selectedUser.avatar || "/placeholder.svg"}
                      alt={selectedUser.name}
                      fill
                      className="object-cover"
                    />
                  </div>

                  <div className="text-center md:text-left">
                    <h3 className="text-xl font-bold">{selectedUser.name}</h3>
                    <p className="text-muted-foreground">{selectedUser.email}</p>
                    <div className="flex gap-2 mt-2 justify-center md:justify-start">
                      {selectedUser.role === "admin" ? <Badge>Admin</Badge> : <Badge variant="outline">Customer</Badge>}

                      {selectedUser.status === "active" ? (
                        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                          Active
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">
                          Inactive
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="border rounded-md p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <User className="h-5 w-5 text-muted-foreground" />
                      <h4 className="font-medium">Account Info</h4>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">User ID:</span>
                        <span>{selectedUser.id}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Join Date:</span>
                        <span>{new Date(selectedUser.joinDate).toLocaleDateString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Last Login:</span>
                        <span>May 10, 2023</span>
                      </div>
                    </div>
                  </div>

                  <div className="border rounded-md p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <ShoppingBag className="h-5 w-5 text-muted-foreground" />
                      <h4 className="font-medium">Order Summary</h4>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Total Orders:</span>
                        <span>{selectedUser.orders}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Total Spent:</span>
                        <span>${selectedUser.totalSpent.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Last Order:</span>
                        <span>{selectedUser.orders > 0 ? "May 5, 2023" : "N/A"}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <Tabs defaultValue="orders">
                <TabsList>
                  <TabsTrigger value="orders">Order History</TabsTrigger>
                  <TabsTrigger value="addresses">Addresses</TabsTrigger>
                </TabsList>

                <TabsContent value="orders" className="border rounded-md">
                  {selectedUser.orders > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Order ID</TableHead>
                          <TableHead>Date</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Total</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {Array(selectedUser.orders)
                          .fill(0)
                          .map((_, i) => (
                            <TableRow key={i}>
                              <TableCell className="font-medium">ORD-{1001 + i}</TableCell>
                              <TableCell>{new Date(Date.now() - i * 86400000 * 10).toLocaleDateString()}</TableCell>
                              <TableCell>
                                <Badge
                                  variant="outline"
                                  className={
                                    i === 0
                                      ? "bg-blue-50 text-blue-700 border-blue-200"
                                      : i === 1
                                        ? "bg-yellow-50 text-yellow-700 border-yellow-200"
                                        : "bg-green-50 text-green-700 border-green-200"
                                  }
                                >
                                  {i === 0 ? "Processing" : i === 1 ? "Shipped" : "Delivered"}
                                </Badge>
                              </TableCell>
                              <TableCell>${(Math.random() * 200 + 50).toFixed(2)}</TableCell>
                            </TableRow>
                          ))}
                      </TableBody>
                    </Table>
                  ) : (
                    <div className="flex flex-col items-center justify-center py-8 text-muted-foreground">
                      <ShoppingBag className="h-10 w-10 mb-2" />
                      <p>No orders yet</p>
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="addresses">
                  <div className="border rounded-md p-4">
                    <h4 className="font-medium mb-2">Shipping Address</h4>
                    <p className="text-sm">
                      {selectedUser.id === "USR-1001"
                        ? "123 Main St, Anytown, AN 12345"
                        : selectedUser.id === "USR-1002"
                          ? "456 Oak Ave, Somewhere, SM 67890"
                          : selectedUser.id === "USR-1003"
                            ? "789 Pine Rd, Elsewhere, EL 10111"
                            : selectedUser.id === "USR-1004"
                              ? "321 Elm St, Nowhere, NW 54321"
                              : "555 Maple Dr, Anyplace, AP 13579"}
                    </p>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsViewUserOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
