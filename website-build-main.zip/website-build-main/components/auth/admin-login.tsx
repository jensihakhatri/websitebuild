"use client"

import React, { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { Lock, ShieldCheck, Mail, Eye, EyeOff } from "lucide-react"

export function AdminLogin() {
  const [isLoading, setIsLoading] = useState(false)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const router = useRouter()
  const { toast } = useToast()

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setIsLoading(true)

    try {
      console.log("Attempting admin login with:", email)

      const response = await fetch("/api/admin/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
      })

      const contentType = response.headers.get("content-type")
      const result = contentType?.includes("application/json")
        ? await response.json()
        : { success: false, message: "Invalid response from server" }

      if (!response.ok) {
        throw new Error(result.message || "Server error")
      }

      if (result.success) {
        toast({
          title: "Success",
          description: "You have been logged in as admin",
        })
        router.push("/admin")
      } else {
        toast({
          title: "Error",
          description: result.message || "Invalid credentials",
          variant: "destructive",
        })
      }
    } catch (error: any) {
      console.error("Admin login error:", error)
      toast({
        title: "Error",
        description: error.message || "An unexpected error occurred",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="p-6">
      <div className="flex justify-center mb-6">
        <div className="p-3 rounded-full bg-cyan-500/10">
          <ShieldCheck className="h-8 w-8 text-cyan-500" />
        </div>
      </div>

      <div className="text-center mb-6">
        <h2 className="text-xl font-semibold">Admin Access</h2>
        <p className="text-sm text-muted-foreground">
          Enter your admin credentials to access the control panel
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="admin-email" className="text-sm font-medium flex items-center">
            <Mail className="h-4 w-4 mr-2 text-muted-foreground" />
            Admin Email
          </Label>
          <Input
            id="admin-email"
            name="email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="admin@example.com"
            className="pl-3 pr-3 py-6 bg-secondary/10 border-secondary/20 focus:border-cyan-500 transition-all"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="admin-password" className="text-sm font-medium flex items-center">
            <Lock className="h-4 w-4 mr-2 text-muted-foreground" />
            Admin Password
          </Label>
          <div className="relative">
            <Input
              id="admin-password"
              name="password"
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="pl-3 pr-10 py-6 bg-secondary/10 border-secondary/20 focus:border-cyan-500 transition-all"
              required
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
            >
              {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        </div>

        <Button
          type="submit"
          className="w-full py-6 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 transition-all duration-300 group"
          disabled={isLoading}
        >
          {isLoading ? (
            "Authenticating..."
          ) : (
            <span className="flex items-center justify-center">
              Access Admin Panel
              <ShieldCheck className="ml-2 h-4 w-4" />
            </span>
          )}
        </Button>
      </form>

      <div className="mt-6 text-center">
        <p className="text-xs text-muted-foreground">Secure access for authorized personnel only</p>
      </div>
    </div>
  )
}
