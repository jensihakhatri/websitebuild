# eCommerce Website Requirements Checklist

## User Side (Frontend)

### Authentication
- [x] Sign up / Login via Firebase Authentication
- [x] Support email/password + OAuth (Google, Facebook)
- [x] Forgot Password / Reset Flow
- [x] Enforce secure password rules

### Home Page
- [x] Featured products, top deals, banners
- [x] Dynamic sliders (editable from Admin Panel)
- [x] Category highlights

### Product Listing Page
- [x] Filter by category, price, rating
- [x] Sort (price, popularity, newest)
- [x] Pagination or infinite scroll

### Product Detail Page
- [x] High-res image carousel
- [x] Price, availability, ratings, add-to-cart
- [x] Urgent Order note box
- [x] WhatsApp box for Esewa payment

### Cart & Checkout
- [x] Full cart management
- [x] Address input with validation
- [x] Urgent Order checkbox + note
- [x] Payment methods: Cash on Delivery, Esewa (with WhatsApp message box)
- [x] Automatically generate secure, unique Order ID
- [x] Only visible to the customer and admin

### Order Tracking & History
- [x] View current order status
- [x] Timeline: Ordered → Processing → Delivered → Received

### User Dashboard
- [x] Edit profile
- [x] Order history
- [x] Saved addresses

### Contact Page
- [x] Dynamic contact form
- [x] Google Maps iframe
- [x] Dynamic contact info (editable by admin)

### Social Media Integration
- [x] Links (Facebook, WhatsApp, Instagram, TikTok)
- [x] Links dynamically set by admin

### Error Handling
- [x] 404 Animated Page for not found pages
- [x] Cleanly styled 500 error page if backend fails
- [x] Retry buttons with friendly UX messages

### UI/UX & Animations
- [x] Smooth transitions with Framer Motion
- [x] Futuristic layout
- [x] Responsive for mobile/tablet/desktop

## Admin Panel (Secure Backend Dashboard)

### Security First
- [x] Access only via admin credentials
- [x] Do not expose panel at any route unless logged in as admin
- [x] Store credentials securely using environment variables
- [x] Block all unauthorized access — return 403 with animation/page
- [x] Admin login must not be bypassable

### Core Admin Features

#### Dashboard Overview
- [x] Real-time analytics: Total orders, revenue, pending orders
- [x] Quick links to urgent orders, flagged products

#### Product Management
- [x] Add/Edit/Delete products
- [x] Set stock, images (via Supabase or Firebase Storage)
- [x] Assign categories/tags

#### Order Management
- [x] View all user orders with filters (status, urgency)
- [x] Change order status: Processing, Delivered, Received
- [x] View user notes for urgent orders
- [x] Dedicated "Urgent Orders" tab

#### User Management
- [x] View all registered users
- [x] Disable/delete accounts
- [x] View order history of users

#### Dynamic Site Settings
- [x] Change homepage banners/sliders
- [x] Edit social media links, WhatsApp number, contact info
- [x] Update about section and footer content

#### Secure Uploads
- [x] Upload images to Firebase Storage or Supabase Bucket
- [x] Validate file size/type before upload

## Technical Stack

### Frontend
- [x] Next.js (for SEO and routing)
- [x] TailwindCSS for styling
- [x] Framer Motion for animations

### Backend & Auth
- [x] Firebase Authentication (for users)
- [x] Admin Auth using secure, environment-based credentials
- [x] Supabase for Product & order management
- [x] Role-based access control
- [x] PostgreSQL queries
- [x] Firebase Firestore (for optional real-time order updates)

### Security Requirements
- [x] Use HTTPS across all environments
- [x] Secure admin routes — authentication must be required
- [x] Sanitize all inputs (forms, product creation, messages)
- [x] Backend code must not be exposed to the frontend
- [x] Store sensitive keys in environment variables (.env)
- [x] Use server-side rendering (Next.js) to protect dynamic data

## Extra Features
- [x] Add to Favorites / Wishlist
- [x] Recently viewed items section
- [x] Search autocomplete
- [x] Dark/Light Mode toggle
- [x] Lazy loading of product images for performance
- [x] Animated skeleton loaders
- [x] Discount/coupon system
- [x] Currency in Nepali Rupees (Rs)
