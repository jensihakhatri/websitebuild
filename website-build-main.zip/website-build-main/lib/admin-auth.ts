import crypto from "crypto"

// Hash password securely
export function hashPassword(password: string): string {
  return crypto.createHash("sha256").update(password).digest("hex")
}

// Client-side cookie functions
export function setCookie(name: string, value: string, days: number) {
  if (typeof window === "undefined") return

  const expires = new Date(Date.now() + days * 24 * 60 * 60 * 1000)
  document.cookie = `${name}=${value};expires=${expires.toUTCString()};path=/;SameSite=Strict${
    process.env.NODE_ENV === "production" ? ";Secure" : ""
  }`
}

export function getCookie(name: string) {
  if (typeof window === "undefined") return null

  const value = `; ${document.cookie}`
  const parts = value.split(`; ${name}=`)
  if (parts.length === 2) return parts.pop()?.split(";").shift() || null
  return null
}

export function deleteCookie(name: string) {
  if (typeof window === "undefined") return

  document.cookie = `${name}=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/`
}

// Admin authentication functions
export async function loginAdmin(email: string, password: string) {
  try {
    const response = await fetch("/api/admin/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, password }),
    })

    return await response.json()
  } catch (error) {
    console.error("Login error:", error)
    return { success: false, message: "Network error" }
  }
}

export async function logoutAdmin() {
  try {
    deleteCookie("admin_session")
    return { success: true }
  } catch (error) {
    console.error("Logout error:", error)
    return { success: false, message: "Error logging out" }
  }
}

export function getAdminSession() {
  return getCookie("admin_session")
}

export async function isAdmin() {
  const sessionId = getAdminSession()
  if (!sessionId) return false

  try {
    const response = await fetch("/api/admin/check", {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    })

    const data = await response.json()
    return data.authenticated
  } catch (error) {
    console.error("Auth check error:", error)
    return false
  }
}

// For compatibility with existing code
export const isAdminAuthenticated = isAdmin
export const setAdminSession = (id: string) => setCookie("admin_session", id, 7)
export const clearAdminSession = () => deleteCookie("admin_session")
export const verifyAdminCredentials = loginAdmin
