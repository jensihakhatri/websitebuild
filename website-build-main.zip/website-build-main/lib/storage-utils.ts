import { supabase } from "./supabase"
import { v4 as uuidv4 } from "uuid"

export async function uploadProductImage(file: File) {
  try {
    const fileExt = file.name.split(".").pop()
    const fileName = `${uuidv4()}.${fileExt}`
    const filePath = `products/${fileName}`

    const { error } = await supabase.storage.from("ecommerce").upload(filePath, file)

    if (error) {
      throw error
    }

    const { data } = supabase.storage.from("ecommerce").getPublicUrl(filePath)

    return { success: true, url: data.publicUrl }
  } catch (error: any) {
    console.error("Error uploading image:", error)
    return { success: false, error: error.message }
  }
}

export async function deleteProductImage(url: string) {
  try {
    // Extract the file path from the URL
    const urlObj = new URL(url)
    const pathParts = urlObj.pathname.split("/")
    const filePath = pathParts.slice(pathParts.indexOf("ecommerce") + 1).join("/")

    const { error } = await supabase.storage.from("ecommerce").remove([filePath])

    if (error) {
      throw error
    }

    return { success: true }
  } catch (error: any) {
    console.error("Error deleting image:", error)
    return { success: false, error: error.message }
  }
}
