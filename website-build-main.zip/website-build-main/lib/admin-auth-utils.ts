import { createHash } from "crypto"

// Hash password securely
export function hashPassword(password: string): string {
  return createHash("sha256").update(password).digest("hex")
}

// Client-side authentication functions
export async function loginAdmin(email: string, password: string) {
  try {
    const response = await fetch("/api/admin/auth", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, password, action: "login" }),
    })

    return await response.json()
  } catch (error) {
    console.error("Login error:", error)
    return { success: false, message: "Network error" }
  }
}

export async function logoutAdmin() {
  try {
    const response = await fetch("/api/admin/auth", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ action: "logout" }),
    })

    return await response.json()
  } catch (error) {
    console.error("Logout error:", error)
    return { success: false, message: "Network error" }
  }
}

export function getAdminSessionFromCookie(): string | null {
  if (typeof document === "undefined") return null

  const match = document.cookie.match(/(^| )admin_session=([^;]+)/)
  return match ? match[2] : null
}

export async function checkAdminAuth() {
  const sessionId = getAdminSessionFromCookie()
  if (!sessionId) return false

  try {
    const response = await fetch("/api/admin/check", {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    })

    const data = await response.json()
    return data.authenticated
  } catch (error) {
    console.error("Auth check error:", error)
    return false
  }
}
