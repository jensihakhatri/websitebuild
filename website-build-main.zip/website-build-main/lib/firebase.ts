import { initializeApp, getApps, getApp } from "firebase/app"
import { getAuth } from "firebase/auth"
import { getFirestore } from "firebase/firestore"
import { getStorage } from "firebase/storage"
import { getAnalytics } from "firebase/analytics"

const firebaseConfig = {
  apiKey: "AIzaSyB6HdwpQn14HFS9x3wOK0Wony6WfgG9-Co",
  authDomain: "newapp-a3762.firebaseapp.com",
  projectId: "newapp-a3762",
  storageBucket: "newapp-a3762.appspot.com", // Fixed storage bucket URL
  messagingSenderId: "416090333375",
  appId: "1:416090333375:web:8cb358f6d390d25f62e60a",
  measurementId: "G-WYY3H3MEYF",
}

// Initialize Firebase
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp()
const auth = getAuth(app)
const db = getFirestore(app)
const storage = getStorage(app)

// Analytics is only available on the client side
const analytics = typeof window !== "undefined" ? getAnalytics(app) : null

// Enable persistence for auth state
if (typeof window !== "undefined") {
  auth.setPersistence({ type: "LOCAL" })
}

export { app, auth, db, storage, analytics }
