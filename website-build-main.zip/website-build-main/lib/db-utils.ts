import { supabase } from "./supabase-client"
import { createServerClient } from "./supabase-server"

// Product types
export type Product = {
  id: string
  name: string
  slug: string
  description: string
  price: number
  discount_percentage: number
  stock: number
  category_id: string
  is_featured: boolean
  is_new: boolean
  rating: number
  review_count: number
  created_at: string
  updated_at: string
  category?: Category
  images?: ProductImage[]
}

export type Category = {
  id: string
  name: string
  slug: string
  description: string
  image_url: string
}

export type ProductImage = {
  id: string
  product_id: string
  image_url: string
  is_primary: boolean
  display_order: number
}

// Client-side functions
export async function getProducts(
  options: {
    featured?: boolean
    category?: string
    limit?: number
  } = {},
) {
  let query = supabase.from("products").select(`
      *,
      category:categories(*),
      images:product_images(*)
    `)

  if (options.featured) {
    query = query.eq("is_featured", true)
  }

  if (options.category) {
    query = query.eq("categories.slug", options.category)
  }

  if (options.limit) {
    query = query.limit(options.limit)
  }

  const { data, error } = await query.order("created_at", { ascending: false })

  if (error) {
    console.error("Error fetching products:", error)
    return []
  }

  return data as Product[]
}

export async function getProductBySlug(slug: string) {
  const { data, error } = await supabase
    .from("products")
    .select(`
      *,
      category:categories(*),
      images:product_images(*)
    `)
    .eq("slug", slug)
    .single()

  if (error) {
    console.error("Error fetching product:", error)
    return null
  }

  return data as Product
}

export async function getCategories() {
  const { data, error } = await supabase.from("categories").select("*").order("name")

  if (error) {
    console.error("Error fetching categories:", error)
    return []
  }

  return data as Category[]
}

// Server-side functions
export async function getProductsServer(
  options: {
    featured?: boolean
    category?: string
    limit?: number
  } = {},
) {
  const supabase = createServerClient()

  let query = supabase.from("products").select(`
      *,
      category:categories(*),
      images:product_images(*)
    `)

  if (options.featured) {
    query = query.eq("is_featured", true)
  }

  if (options.category) {
    query = query.eq("categories.slug", options.category)
  }

  if (options.limit) {
    query = query.limit(options.limit)
  }

  const { data, error } = await query.order("created_at", { ascending: false })

  if (error) {
    console.error("Error fetching products:", error)
    return []
  }

  return data as Product[]
}

export async function getSiteSettings() {
  const { data, error } = await supabase.from("site_settings").select("*")

  if (error) {
    console.error("Error fetching site settings:", error)
    return {}
  }

  // Convert array of settings to object
  const settings = data.reduce((acc: Record<string, any>, item) => {
    try {
      acc[item.setting_key] = JSON.parse(item.setting_value)
    } catch (e) {
      acc[item.setting_key] = item.setting_value
    }
    return acc
  }, {})

  return settings
}
