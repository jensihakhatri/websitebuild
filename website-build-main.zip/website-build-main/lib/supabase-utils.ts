import { supabase } from "./supabase"

// Products
export async function getProducts(options = {}) {
  const { data, error } = await supabase
    .from("products")
    .select(`
      *,
      category:categories(*),
      images:product_images(*)
    `)
    .order("created_at", { ascending: false })

  if (error) {
    console.error("Error fetching products:", error)
    return []
  }

  return data || []
}

export async function getProductBySlug(slug: string) {
  const { data, error } = await supabase
    .from("products")
    .select(`
      *,
      category:categories(*),
      images:product_images(*)
    `)
    .eq("slug", slug)
    .single()

  if (error) {
    console.error("Error fetching product:", error)
    return null
  }

  return data
}

// Orders
export async function getUserOrders(userId: string) {
  const { data, error } = await supabase
    .from("orders")
    .select(`
      *,
      items:order_items(
        *,
        product:products(*)
      )
    `)
    .eq("user_id", userId)
    .order("created_at", { ascending: false })

  if (error) {
    console.error("Error fetching orders:", error)
    return []
  }

  return data || []
}

// Wishlist
export async function getUserWishlist(userId: string) {
  const { data, error } = await supabase
    .from("wishlist_items")
    .select(`
      *,
      product:products(*)
    `)
    .eq("user_id", userId)

  if (error) {
    console.error("Error fetching wishlist:", error)
    return []
  }

  return data || []
}

// Cart
export async function getUserCart(userId: string) {
  const { data, error } = await supabase
    .from("cart_items")
    .select(`
      *,
      product:products(*)
    `)
    .eq("user_id", userId)

  if (error) {
    console.error("Error fetching cart:", error)
    return []
  }

  return data || []
}

// Admin functions
export async function getAllOrders() {
  const { data, error } = await supabase
    .from("orders")
    .select(`
      *,
      user:users(*),
      items:order_items(
        *,
        product:products(*)
      )
    `)
    .order("created_at", { ascending: false })

  if (error) {
    console.error("Error fetching all orders:", error)
    return []
  }

  return data || []
}

export async function getAllUsers() {
  const { data, error } = await supabase.from("users").select("*").order("created_at", { ascending: false })

  if (error) {
    console.error("Error fetching all users:", error)
    return []
  }

  return data || []
}

export async function getSiteSettings() {
  const { data, error } = await supabase.from("site_settings").select("*")

  if (error) {
    console.error("Error fetching site settings:", error)
    return {}
  }

  // Convert array of settings to object
  const settings = data.reduce((acc, item) => {
    acc[item.setting_key] = item.setting_value
    return acc
  }, {})

  return settings
}
