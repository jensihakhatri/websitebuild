import { cookies } from "next/headers"
import { createHash } from "crypto"
import { createServerClient } from "./supabase-server"

// Hash password securely
export function hashPassword(password: string): string {
  return createHash("sha256").update(password).digest("hex")
}

// Verify admin credentials
export async function verifyAdminCredentials(email: string, password: string) {
  const supabase = createServerClient()

  // Check if admin exists in users table
  const { data: adminUser } = await supabase.from("users").select("*").eq("email", email).eq("is_admin", true).single()

  if (!adminUser) {
    return { success: false, message: "Invalid admin credentials" }
  }

  // Check credentials in admin_credentials table
  const { data: credentials } = await supabase.from("admin_credentials").select("*").eq("email", email).single()

  // If no credentials exist yet, create them with the default password
  if (!credentials) {
    const hashedPassword = hashPassword(password)

    const { error } = await supabase.from("admin_credentials").insert({
      id: adminUser.id,
      email: email,
      password_hash: hashedPassword,
    })

    if (error) {
      console.error("Error creating admin credentials:", error)
      return { success: false, message: "Error setting up admin account" }
    }

    return { success: true, adminId: adminUser.id }
  }

  // Verify password
  const hashedPassword = hashPassword(password)
  if (credentials.password_hash !== hashedPassword) {
    return { success: false, message: "Invalid admin credentials" }
  }

  return { success: true, adminId: adminUser.id }
}

// Set admin session cookie
export function setAdminSession(adminId: string) {
  const expires = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 days
  cookies().set("admin_session", adminId, {
    expires,
    httpOnly: true,
    path: "/",
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict",
  })
}

// Clear admin session
export function clearAdminSession() {
  cookies().delete("admin_session")
}

// Get current admin session
export function getAdminSession() {
  return cookies().get("admin_session")?.value
}

// Check if user is authenticated as admin
export async function isAdminAuthenticated() {
  const adminId = getAdminSession()

  if (!adminId) {
    return false
  }

  const supabase = createServerClient()

  const { data } = await supabase.from("users").select("*").eq("id", adminId).eq("is_admin", true).single()

  return !!data
}

// Export isAdmin as an alias for isAdminAuthenticated
export const isAdmin = isAdminAuthenticated
