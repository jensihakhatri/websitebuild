import { createHash } from "crypto"
import { createClient } from "./supabase-client"

// Hash password securely
export function hashPassword(password: string): string {
  return createHash("sha256").update(password).digest("hex")
}

// Client-side cookie functions
function setCookie(name: string, value: string, days: number) {
  const expires = new Date(Date.now() + days * 24 * 60 * 60 * 1000)
  document.cookie = `${name}=${value};expires=${expires.toUTCString()};path=/;SameSite=Strict${
    process.env.NODE_ENV === "production" ? ";Secure" : ""
  }`
}

function getCookie(name: string) {
  const value = `; ${document.cookie}`
  const parts = value.split(`; ${name}=`)
  if (parts.length === 2) return parts.pop()?.split(";").shift() || null
  return null
}

function deleteCookie(name: string) {
  document.cookie = `${name}=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/`
}

// Verify admin credentials
export async function verifyAdminCredentials(email: string, password: string) {
  const supabase = createClient()

  // Check if admin exists in users table
  const { data: adminUser } = await supabase.from("users").select("*").eq("email", email).eq("is_admin", true).single()

  if (!adminUser) {
    return { success: false, message: "Invalid admin credentials" }
  }

  // Check credentials in admin_credentials table
  const { data: credentials } = await supabase.from("admin_credentials").select("*").eq("email", email).single()

  if (!credentials) {
    return { success: false, message: "Admin credentials not set up" }
  }

  // Verify password
  const hashedPassword = hashPassword(password)
  if (credentials.password_hash !== hashedPassword) {
    return { success: false, message: "Invalid admin credentials" }
  }

  return { success: true, adminId: adminUser.id }
}

// Set admin session
export function setAdminSession(adminId: string) {
  setCookie("admin_session", adminId, 7) // 7 days
  localStorage.setItem("admin_session", adminId)
}

// Clear admin session
export function clearAdminSession() {
  deleteCookie("admin_session")
  localStorage.removeItem("admin_session")
}

// Get current admin session
export function getAdminSession() {
  return getCookie("admin_session") || localStorage.getItem("admin_session")
}

// Check if user is authenticated as admin
export async function isAdminAuthenticated() {
  const adminId = getAdminSession()

  if (!adminId) {
    return false
  }

  const supabase = createClient()

  const { data } = await supabase.from("users").select("*").eq("id", adminId).eq("is_admin", true).single()

  return !!data
}

// Export isAdmin as an alias for isAdminAuthenticated
export const isAdmin = isAdminAuthenticated
