import { Suspense } from "react"
import { notFound } from "next/navigation"
import { createServerClient } from "@/lib/supabase-server"
import ProductDetail from "./product-detail"

export async function generateMetadata({ params }: { params: { slug: string } }) {
  const supabase = createServerClient()

  const { data: product } = await supabase
    .from("products")
    .select(`
      name,
      description,
      price,
      category:categories(name)
    `)
    .eq("slug", params.slug)
    .single()

  if (!product) {
    return {
      title: "Product Not Found",
      description: "The requested product could not be found",
    }
  }

  return {
    title: product.name,
    description: product.description?.substring(0, 160) || `Buy ${product.name} at the best price`,
  }
}

export default async function ProductPage({ params }: { params: { slug: string } }) {
  const supabase = createServerClient()

  const { data: product, error } = await supabase
    .from("products")
    .select(`
      *,
      category:categories(*),
      images:product_images(*)
    `)
    .eq("slug", params.slug)
    .single()

  if (error || !product) {
    notFound()
  }

  // Get related products from the same category
  const { data: relatedProducts } = await supabase
    .from("products")
    .select(`
      id,
      name,
      slug,
      price,
      discount_percentage,
      rating,
      category:categories(name),
      images:product_images(image_url, is_primary)
    `)
    .eq("category_id", product.category_id)
    .neq("id", product.id)
    .limit(4)

  return (
    <div className="container mx-auto px-4 py-8">
      <Suspense fallback={<ProductSkeleton />}>
        <ProductDetail product={product} relatedProducts={relatedProducts || []} />
      </Suspense>
    </div>
  )
}

function ProductSkeleton() {
  return (
    <div className="flex flex-col lg:flex-row gap-8 animate-pulse">
      <div className="lg:w-1/2">
        <div className="relative h-[400px] w-full mb-4 rounded-lg bg-gray-200" />
        <div className="grid grid-cols-4 gap-2">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="h-20 bg-gray-200 rounded-md" />
          ))}
        </div>
      </div>
      <div className="lg:w-1/2 space-y-4">
        <div className="h-8 bg-gray-200 rounded w-3/4" />
        <div className="h-4 bg-gray-200 rounded w-1/4" />
        <div className="h-6 bg-gray-200 rounded w-1/3" />
        <div className="h-24 bg-gray-200 rounded w-full" />
        <div className="h-10 bg-gray-200 rounded w-full" />
      </div>
    </div>
  )
}
