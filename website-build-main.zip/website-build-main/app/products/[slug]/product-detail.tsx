"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Heart, Minus, Plus, Share2, ShoppingCart, Star, Truck } from "lucide-react"

interface ProductDetailProps {
  product: any
  relatedProducts: any[]
}

export default function ProductDetail({ product, relatedProducts }: ProductDetailProps) {
  const [selectedImage, setSelectedImage] = useState(0)
  const [quantity, setQuantity] = useState(1)
  const [isUrgent, setIsUrgent] = useState(false)
  const [urgentNote, setUrgentNote] = useState("")

  const images = product.images || []
  const discountedPrice = product.price * (1 - product.discount_percentage / 100)

  const incrementQuantity = () => {
    if (quantity < product.stock) {
      setQuantity(quantity + 1)
    }
  }

  const decrementQuantity = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1)
    }
  }

  return (
    <div className="flex flex-col lg:flex-row gap-8">
      {/* Product Images */}
      <div className="lg:w-1/2">
        <div className="relative h-[400px] md:h-[500px] w-full mb-4 rounded-lg overflow-hidden">
          <Image
            src={images[selectedImage]?.image_url || "/placeholder.svg?height=600&width=600"}
            alt={product.name}
            fill
            className="object-contain"
            priority
          />
        </div>
        <div className="grid grid-cols-4 gap-2">
          {images.map((image: any, index: number) => (
            <div
              key={index}
              className={`relative h-20 cursor-pointer rounded-md overflow-hidden border-2 ${
                selectedImage === index ? "border-primary" : "border-transparent"
              }`}
              onClick={() => setSelectedImage(index)}
            >
              <Image
                src={image.image_url || "/placeholder.svg?height=150&width=150"}
                alt={`${product.name} - Image ${index + 1}`}
                fill
                className="object-cover"
              />
            </div>
          ))}
        </div>
      </div>

      {/* Product Info */}
      <div className="lg:w-1/2">
        <div className="flex flex-col space-y-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Link href={`/categories/${product.category?.slug || ""}`}>
                <Badge variant="outline">{product.category?.name}</Badge>
              </Link>
              {product.is_new && <Badge>New</Badge>}
              {product.discount_percentage > 0 && (
                <Badge variant="destructive">{product.discount_percentage}% OFF</Badge>
              )}
            </div>

            <h1 className="text-3xl font-bold">{product.name}</h1>

            <div className="flex items-center mt-2">
              <div className="flex">
                {Array(5)
                  .fill(0)
                  .map((_, i) => (
                    <Star
                      key={i}
                      className={`h-5 w-5 ${
                        i < Math.floor(product.rating)
                          ? "text-yellow-400 fill-yellow-400"
                          : i < product.rating
                            ? "text-yellow-400 fill-yellow-400 opacity-50"
                            : "text-gray-300"
                      }`}
                    />
                  ))}
              </div>
              <span className="ml-2 text-sm text-muted-foreground">
                {product.rating} ({product.review_count || 0} reviews)
              </span>
            </div>
          </div>

          <div className="flex items-center">
            <div className="text-3xl font-bold">Rs {discountedPrice.toFixed(2)}</div>
            {product.discount_percentage > 0 && (
              <div className="ml-2 text-xl text-muted-foreground line-through">Rs {product.price.toFixed(2)}</div>
            )}
          </div>

          <Separator />

          <div>
            <p className="text-muted-foreground">{product.description}</p>
          </div>

          <div className="flex items-center">
            <div className="text-sm text-muted-foreground mr-2">Availability:</div>
            {product.stock > 0 ? (
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                In Stock ({product.stock} available)
              </Badge>
            ) : (
              <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                Out of Stock
              </Badge>
            )}
          </div>

          <div className="flex flex-col space-y-4">
            <div className="flex items-center">
              <div className="flex items-center border rounded-md">
                <Button variant="ghost" size="icon" onClick={decrementQuantity} disabled={quantity <= 1}>
                  <Minus className="h-4 w-4" />
                </Button>
                <div className="w-12 text-center">{quantity}</div>
                <Button variant="ghost" size="icon" onClick={incrementQuantity} disabled={quantity >= product.stock}>
                  <Plus className="h-4 w-4" />
                </Button>
              </div>

              <div className="ml-4 text-sm text-muted-foreground">
                Total: Rs {(discountedPrice * quantity).toFixed(2)}
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-2">
              <Button className="sm:flex-1" size="lg" disabled={product.stock <= 0}>
                <ShoppingCart className="mr-2 h-5 w-5" />
                Add to Cart
              </Button>
              <Button variant="outline" size="lg" className="sm:flex-1" disabled={product.stock <= 0}>
                Buy Now
              </Button>
              <Button variant="outline" size="icon" className="h-12 w-12">
                <Heart className="h-5 w-5" />
              </Button>
              <Button variant="outline" size="icon" className="h-12 w-12">
                <Share2 className="h-5 w-5" />
              </Button>
            </div>
          </div>

          <div className="flex items-start space-x-2 p-4 bg-muted rounded-lg">
            <Checkbox
              id="urgent-order"
              checked={isUrgent}
              onCheckedChange={(checked) => setIsUrgent(checked as boolean)}
            />
            <div className="space-y-1">
              <Label htmlFor="urgent-order" className="font-medium">
                Mark as Urgent Order
              </Label>
              <p className="text-sm text-muted-foreground">
                Urgent orders are prioritized and shipped within 24 hours.
              </p>
              {isUrgent && (
                <Textarea
                  placeholder="Add any special instructions for your urgent order..."
                  value={urgentNote}
                  onChange={(e) => setUrgentNote(e.target.value)}
                  className="mt-2"
                />
              )}
            </div>
          </div>

          <div className="flex items-center text-sm text-muted-foreground">
            <Truck className="mr-2 h-4 w-4" />
            Free shipping on orders over Rs 1000
          </div>
        </div>
      </div>

      {/* Product Details Tabs */}
      <div className="mt-12 w-full">
        <Tabs defaultValue="details">
          <TabsList className="w-full justify-start">
            <TabsTrigger value="details">Details</TabsTrigger>
            <TabsTrigger value="specifications">Specifications</TabsTrigger>
            <TabsTrigger value="reviews">Reviews</TabsTrigger>
            <TabsTrigger value="shipping">Shipping & Returns</TabsTrigger>
          </TabsList>

          <TabsContent value="details" className="py-4">
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-semibold mb-4">Product Description</h3>
                <p className="text-muted-foreground mb-6">{product.description}</p>
                <p className="text-muted-foreground">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam auctor, nisl eget ultricies tincidunt,
                  nisl nisl aliquam nisl, eget ultricies nisl nisl eget nisl. Nullam auctor, nisl eget ultricies
                  tincidunt, nisl nisl aliquam nisl, eget ultricies nisl nisl eget nisl.
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-4">Key Features</h3>
                <ul className="space-y-2">
                  {["Feature 1", "Feature 2", "Feature 3", "Feature 4", "Feature 5"].map((feature, index) => (
                    <li key={index} className="flex items-center">
                      <div className="h-2 w-2 rounded-full bg-primary mr-2" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="specifications" className="py-4">
            <h3 className="text-xl font-semibold mb-4">Technical Specifications</h3>
            <div className="grid md:grid-cols-2 gap-x-8 gap-y-2">
              {[
                { key: "Brand", value: "NepalMart" },
                { key: "Model", value: "NM-2023" },
                { key: "Color", value: "Black" },
                { key: "Weight", value: "250g" },
                { key: "Dimensions", value: "10 x 5 x 2 cm" },
                { key: "Warranty", value: "1 Year" },
              ].map(({ key, value }) => (
                <div key={key} className="py-2 border-b">
                  <div className="flex justify-between">
                    <span className="font-medium">{key}</span>
                    <span className="text-muted-foreground">{value}</span>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="reviews" className="py-4">
            <div className="flex flex-col md:flex-row gap-8">
              <div className="md:w-1/3">
                <h3 className="text-xl font-semibold mb-4">Customer Reviews</h3>
                <div className="flex items-center mb-2">
                  <div className="text-3xl font-bold mr-2">{product.rating}</div>
                  <div>
                    <div className="flex">
                      {Array(5)
                        .fill(0)
                        .map((_, i) => (
                          <Star
                            key={i}
                            className={`h-5 w-5 ${
                              i < Math.floor(product.rating)
                                ? "text-yellow-400 fill-yellow-400"
                                : i < product.rating
                                  ? "text-yellow-400 fill-yellow-400 opacity-50"
                                  : "text-gray-300"
                            }`}
                          />
                        ))}
                    </div>
                    <div className="text-sm text-muted-foreground">Based on {product.review_count || 0} reviews</div>
                  </div>
                </div>

                <div className="space-y-2 mt-4">
                  {[5, 4, 3, 2, 1].map((rating) => {
                    const percentage = Math.floor(Math.random() * 100)
                    return (
                      <div key={rating} className="flex items-center">
                        <div className="flex items-center w-20">
                          <span className="mr-1">{rating}</span>
                          <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                        </div>
                        <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                          <div className="h-full bg-yellow-400" style={{ width: `${percentage}%` }} />
                        </div>
                        <div className="w-12 text-right text-sm text-muted-foreground">{percentage}%</div>
                      </div>
                    )
                  })}
                </div>

                <Button className="mt-6 w-full">Write a Review</Button>
              </div>

              <div className="md:w-2/3">
                <h3 className="text-xl font-semibold mb-4">Recent Reviews</h3>
                <div className="space-y-6">
                  {Array(3)
                    .fill(0)
                    .map((_, i) => (
                      <div key={i} className="border-b pb-6">
                        <div className="flex justify-between mb-2">
                          <div className="font-semibold">John Doe</div>
                          <div className="text-sm text-muted-foreground">
                            {new Date(Date.now() - i * 86400000).toLocaleDateString()}
                          </div>
                        </div>
                        <div className="flex mb-2">
                          {Array(5)
                            .fill(0)
                            .map((_, j) => (
                              <Star
                                key={j}
                                className={`h-4 w-4 ${j < 5 - i ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
                              />
                            ))}
                        </div>
                        <p className="text-muted-foreground">
                          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam auctor, nisl eget ultricies
                          tincidunt, nisl nisl aliquam nisl, eget ultricies nisl nisl eget nisl.
                        </p>
                      </div>
                    ))}
                </div>

                <Button variant="outline" className="mt-4">
                  Load More Reviews
                </Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="shipping" className="py-4">
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-semibold mb-4">Shipping Information</h3>
                <Accordion type="single" collapsible className="w-full">
                  <AccordionItem value="shipping-1">
                    <AccordionTrigger>Delivery Options</AccordionTrigger>
                    <AccordionContent>
                      <ul className="space-y-2 text-muted-foreground">
                        <li>Standard Shipping (3-5 business days): Free on orders over Rs 1000</li>
                        <li>Express Shipping (1-2 business days): Rs 250</li>
                        <li>Same Day Delivery (select areas): Rs 500</li>
                      </ul>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="shipping-2">
                    <AccordionTrigger>Shipping Restrictions</AccordionTrigger>
                    <AccordionContent>
                      <p className="text-muted-foreground">
                        We currently ship to all major cities in Nepal. Remote area delivery may take additional time.
                      </p>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="shipping-3">
                    <AccordionTrigger>Tracking Your Order</AccordionTrigger>
                    <AccordionContent>
                      <p className="text-muted-foreground">
                        Once your order ships, you will receive a confirmation email with tracking information. You can
                        also track your order in your account dashboard.
                      </p>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-4">Return Policy</h3>
                <Accordion type="single" collapsible className="w-full">
                  <AccordionItem value="return-1">
                    <AccordionTrigger>Return Window</AccordionTrigger>
                    <AccordionContent>
                      <p className="text-muted-foreground">
                        You have 7 days from the date of delivery to return your item. The item must be in its original
                        condition and packaging.
                      </p>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="return-2">
                    <AccordionTrigger>Return Process</AccordionTrigger>
                    <AccordionContent>
                      <ol className="space-y-2 text-muted-foreground list-decimal pl-4">
                        <li>Initiate a return in your account dashboard</li>
                        <li>Print the prepaid return shipping label</li>
                        <li>Package the item securely</li>
                        <li>Drop off the package at any authorized shipping location</li>
                      </ol>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="return-3">
                    <AccordionTrigger>Refund Policy</AccordionTrigger>
                    <AccordionContent>
                      <p className="text-muted-foreground">
                        Refunds will be issued to the original payment method within 5-7 business days after we receive
                        and inspect the returned item.
                      </p>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Related Products */}
      {relatedProducts.length > 0 && (
        <div className="mt-16 w-full">
          <h2 className="text-2xl font-bold mb-6">You May Also Like</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {relatedProducts.map((product) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                whileHover={{ y: -5 }}
              >
                <Link href={`/products/${product.slug}`}>
                  <div className="group rounded-lg overflow-hidden border">
                    <div className="relative h-[200px] w-full">
                      <Image
                        src={
                          product.images?.find((img: any) => img.is_primary)?.image_url ||
                          product.images?.[0]?.image_url ||
                          "/placeholder.svg?height=300&width=300" ||
                          "/placeholder.svg"
                        }
                        alt={product.name}
                        fill
                        className="object-cover transition-transform duration-300 ease-in-out group-hover:scale-105"
                      />
                    </div>
                    <div className="p-4">
                      <div className="text-sm text-muted-foreground mb-1">{product.category?.name}</div>
                      <h3 className="font-semibold line-clamp-1">{product.name}</h3>
                      <div className="flex items-center mt-1 mb-2">
                        <div className="flex">
                          {Array(5)
                            .fill(0)
                            .map((_, i) => (
                              <Star
                                key={i}
                                className={`h-3 w-3 ${
                                  i < Math.floor(product.rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                                }`}
                              />
                            ))}
                        </div>
                        <span className="text-xs text-muted-foreground ml-1">({product.rating})</span>
                      </div>
                      <div className="font-bold">Rs {product.price.toFixed(2)}</div>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
