"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { motion } from "framer-motion"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Heart, Search, ShoppingCart, SlidersHorizontal, Star, X } from "lucide-react"
import { supabase } from "@/lib/supabase-client"
import { useAuth } from "@/components/auth-provider"
import { useRouter } from "next/navigation"

export default function ProductsPage() {
  const { user } = useAuth()
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")
  const [priceRange, setPriceRange] = useState([0, 10000])
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])
  const [sortBy, setSortBy] = useState("featured")
  const [showFilters, setShowFilters] = useState(false)
  const [hoveredProduct, setHoveredProduct] = useState<string | null>(null)
  const [activeFilters, setActiveFilters] = useState<string[]>([])

  const [products, setProducts] = useState<any[]>([])
  const [categories, setCategories] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)

    // Redirect if not logged in
    if (mounted && !user) {
      router.push("/auth/login")
      return
    }

    async function fetchData() {
      if (!user) return

      setLoading(true)

      // Fetch categories
      const { data: categoriesData } = await supabase.from("categories").select("id, name, slug")

      // Fetch products with their primary images
      const { data: productsData } = await supabase.from("products").select(`
          id, 
          name, 
          slug,
          description, 
          price, 
          discount_percentage, 
          stock,
          is_new,
          is_featured,
          rating,
          category_id,
          categories:categories(name, slug),
          images:product_images(image_url, is_primary)
        `)

      if (categoriesData) setCategories(categoriesData)
      if (productsData) setProducts(productsData)

      setLoading(false)
    }

    if (user) {
      fetchData()
    }
  }, [user, router, mounted])

  // If not mounted or user not logged in, show loading state
  if (!mounted || !user) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-center items-center h-[60vh]">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
        </div>
      </div>
    )
  }

  const toggleCategory = (categoryId: string) => {
    setSelectedCategories((prev) => {
      const newCategories = prev.includes(categoryId) ? prev.filter((id) => id !== categoryId) : [...prev, categoryId]

      // Update active filters
      updateActiveFilters(newCategories, priceRange)

      return newCategories
    })
  }

  const updateActiveFilters = (categories: string[], prices: number[]) => {
    const filters: string[] = []

    // Add category filters
    categories.forEach((cat) => {
      const category = categories.find((c) => c.slug === cat)
      if (category) {
        filters.push(`Category: ${category.name}`)
      }
    })

    // Add price filter if it's not the default
    if (prices[0] > 0 || prices[1] < 10000) {
      filters.push(`Price: Rs ${prices[0]} - Rs ${prices[1]}`)
    }

    setActiveFilters(filters)
  }

  const removeFilter = (filter: string) => {
    if (filter.startsWith("Category:")) {
      const categoryName = filter.replace("Category: ", "")
      const category = categories.find((c) => c.name === categoryName)
      if (category) {
        toggleCategory(category.slug)
      }
    } else if (filter.startsWith("Price:")) {
      setPriceRange([0, 10000])
      updateActiveFilters(selectedCategories, [0, 10000])
    }
  }

  const handlePriceChange = (values: number[]) => {
    setPriceRange(values)
    updateActiveFilters(selectedCategories, values)
  }

  const filteredProducts = products.filter((product) => {
    // Filter by search query
    if (searchQuery && !product.name.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false
    }

    // Filter by price range
    if (product.price < priceRange[0] || product.price > priceRange[1]) {
      return false
    }

    // Filter by category
    if (selectedCategories.length > 0 && !selectedCategories.includes(product.categories?.slug)) {
      return false
    }

    return true
  })

  // Sort products
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case "price-low":
        return a.price - b.price
      case "price-high":
        return b.price - a.price
      case "rating":
        return b.rating - a.rating
      case "newest":
        return new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
      default:
        return b.is_featured ? 1 : -1
    }
  })

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row gap-8">
        {/* Mobile filter button */}
        <div className="md:hidden flex justify-between items-center mb-4">
          <h1 className="text-2xl font-bold">Products</h1>
          <Button variant="outline" onClick={() => setShowFilters(!showFilters)}>
            <SlidersHorizontal className="mr-2 h-4 w-4" />
            Filters
          </Button>
        </div>

        {/* Sidebar filters */}
        <div className={`md:w-1/4 ${showFilters ? "block" : "hidden md:block"}`}>
          <div className="sticky top-20 space-y-6 bg-card rounded-lg p-6 shadow-sm">
            <div>
              <h2 className="text-lg font-semibold mb-4">Search</h2>
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search products..."
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>

            <div>
              <h2 className="text-lg font-semibold mb-4">Categories</h2>
              <div className="space-y-2">
                {categories.map((category) => (
                  <div key={category.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={category.slug}
                      checked={selectedCategories.includes(category.slug)}
                      onCheckedChange={() => toggleCategory(category.slug)}
                      className="data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground"
                    />
                    <Label htmlFor={category.slug} className="cursor-pointer">
                      {category.name}
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h2 className="text-lg font-semibold mb-4">Price Range</h2>
              <div className="space-y-6">
                <div className="pt-4">
                  <Slider
                    defaultValue={[0, 10000]}
                    max={10000}
                    step={100}
                    value={priceRange}
                    onValueChange={handlePriceChange}
                    className="my-6"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div className="relative w-full">
                    <Input
                      type="number"
                      value={priceRange[0]}
                      onChange={(e) => {
                        const value = Number.parseInt(e.target.value)
                        if (!isNaN(value) && value >= 0 && value <= priceRange[1]) {
                          handlePriceChange([value, priceRange[1]])
                        }
                      }}
                      className="pl-6"
                    />
                    <span className="absolute left-2 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">₹</span>
                  </div>
                  <span className="mx-2">-</span>
                  <div className="relative w-full">
                    <Input
                      type="number"
                      value={priceRange[1]}
                      onChange={(e) => {
                        const value = Number.parseInt(e.target.value)
                        if (!isNaN(value) && value >= priceRange[0]) {
                          handlePriceChange([priceRange[0], value])
                        }
                      }}
                      className="pl-6"
                    />
                    <span className="absolute left-2 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">₹</span>
                  </div>
                </div>
              </div>
            </div>

            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="ratings">
                <AccordionTrigger>Ratings</AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-2">
                    {[5, 4, 3, 2, 1].map((rating) => (
                      <div key={rating} className="flex items-center space-x-2">
                        <Checkbox id={`rating-${rating}`} />
                        <Label htmlFor={`rating-${rating}`} className="flex items-center cursor-pointer">
                          {Array(5)
                            .fill(0)
                            .map((_, i) => (
                              <Star
                                key={i}
                                className={`h-4 w-4 ${
                                  i < rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                                }`}
                              />
                            ))}
                          <span className="ml-1">& Up</span>
                        </Label>
                      </div>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="availability">
                <AccordionTrigger>Availability</AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="in-stock" />
                      <Label htmlFor="in-stock" className="cursor-pointer">
                        In Stock
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="out-of-stock" />
                      <Label htmlFor="out-of-stock" className="cursor-pointer">
                        Out of Stock
                      </Label>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>
            </Accordion>

            <div className="pt-4">
              <Button
                variant="outline"
                className="w-full"
                onClick={() => {
                  setSearchQuery("")
                  setPriceRange([0, 10000])
                  setSelectedCategories([])
                  setSortBy("featured")
                  setActiveFilters([])
                }}
              >
                Reset All Filters
              </Button>
            </div>
          </div>
        </div>

        {/* Product grid */}
        <div className="md:w-3/4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
            <div>
              <h1 className="text-2xl font-bold hidden md:block">Products</h1>
              <p className="text-muted-foreground">
                Showing {sortedProducts.length} of {products.length} products
              </p>
            </div>

            <div className="w-full sm:w-auto mt-4 sm:mt-0">
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-full sm:w-[180px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="featured">Featured</SelectItem>
                  <SelectItem value="price-low">Price: Low to High</SelectItem>
                  <SelectItem value="price-high">Price: High to Low</SelectItem>
                  <SelectItem value="rating">Highest Rated</SelectItem>
                  <SelectItem value="newest">Newest</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Active filters */}
          {activeFilters.length > 0 && (
            <div className="mb-6">
              <div className="flex flex-wrap gap-2 items-center">
                <span className="text-sm font-medium">Active Filters:</span>
                {activeFilters.map((filter, index) => (
                  <Badge key={index} variant="secondary" className="flex items-center gap-1 px-3 py-1">
                    {filter}
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-4 w-4 p-0 ml-1"
                      onClick={() => removeFilter(filter)}
                    >
                      <X className="h-3 w-3" />
                      <span className="sr-only">Remove filter</span>
                    </Button>
                  </Badge>
                ))}
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-xs h-7"
                  onClick={() => {
                    setSearchQuery("")
                    setPriceRange([0, 10000])
                    setSelectedCategories([])
                    setActiveFilters([])
                  }}
                >
                  Clear All
                </Button>
              </div>
            </div>
          )}

          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="border rounded-lg p-4 h-[400px] animate-pulse">
                  <div className="bg-gray-200 h-[200px] w-full rounded-md mb-4"></div>
                  <div className="bg-gray-200 h-4 w-1/4 rounded mb-2"></div>
                  <div className="bg-gray-200 h-6 w-3/4 rounded mb-4"></div>
                  <div className="bg-gray-200 h-4 w-1/2 rounded mb-4"></div>
                  <div className="bg-gray-200 h-10 w-full rounded"></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {sortedProducts.map((product) => (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                  whileHover={{ y: -5 }}
                >
                  <Card
                    className="h-full overflow-hidden"
                    onMouseEnter={() => setHoveredProduct(product.id)}
                    onMouseLeave={() => setHoveredProduct(null)}
                  >
                    <div className="relative pt-4 px-4">
                      {product.is_new && <Badge className="absolute top-6 left-6 z-10">New</Badge>}
                      {product.discount_percentage > 0 && (
                        <Badge variant="destructive" className="absolute top-6 right-6 z-10">
                          {product.discount_percentage}% OFF
                        </Badge>
                      )}
                      <div className="relative h-[200px] w-full mb-4 overflow-hidden rounded-md">
                        <Image
                          src={
                            product.images?.find((img: any) => img.is_primary)?.image_url ||
                            product.images?.[0]?.image_url ||
                            "/placeholder.svg?height=300&width=300" ||
                            "/placeholder.svg" ||
                            "/placeholder.svg"
                          }
                          alt={product.name}
                          fill
                          className="object-cover transition-transform duration-300 ease-in-out group-hover:scale-105"
                        />
                        {hoveredProduct === product.id && (
                          <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                            <Link href={`/products/${product.slug}`}>
                              <Button>Quick View</Button>
                            </Link>
                          </div>
                        )}
                      </div>
                    </div>

                    <CardContent className="p-4">
                      <div className="text-sm text-muted-foreground mb-1">{product.categories?.name}</div>
                      <Link href={`/products/${product.slug}`} className="hover:underline">
                        <h3 className="font-semibold text-lg line-clamp-2 mb-1">{product.name}</h3>
                      </Link>
                      <div className="flex items-center mb-2">
                        {Array(5)
                          .fill(0)
                          .map((_, i) => (
                            <Star
                              key={i}
                              className={`h-4 w-4 ${
                                i < Math.floor(product.rating)
                                  ? "text-yellow-400 fill-yellow-400"
                                  : i < product.rating
                                    ? "text-yellow-400 fill-yellow-400 opacity-50"
                                    : "text-gray-300"
                              }`}
                            />
                          ))}
                        <span className="text-xs text-muted-foreground ml-1">({product.rating})</span>
                      </div>
                      <div className="flex items-center">
                        {product.discount_percentage > 0 ? (
                          <>
                            <span className="font-bold text-lg">
                              Rs {(product.price * (1 - product.discount_percentage / 100)).toFixed(2)}
                            </span>
                            <span className="text-muted-foreground line-through ml-2">
                              Rs {product.price.toFixed(2)}
                            </span>
                          </>
                        ) : (
                          <span className="font-bold text-lg">Rs {product.price.toFixed(2)}</span>
                        )}
                      </div>
                    </CardContent>

                    <CardFooter className="p-4 pt-0 flex gap-2">
                      <Button className="w-full" size="sm">
                        <ShoppingCart className="mr-2 h-4 w-4" />
                        Add to Cart
                      </Button>
                      <Button variant="outline" size="icon" className="shrink-0">
                        <Heart className="h-4 w-4" />
                        <span className="sr-only">Add to wishlist</span>
                      </Button>
                    </CardFooter>
                  </Card>
                </motion.div>
              ))}
            </div>
          )}

          {!loading && sortedProducts.length === 0 && (
            <div className="text-center py-12 bg-card rounded-lg shadow-sm">
              <h3 className="text-lg font-semibold mb-2">No products found</h3>
              <p className="text-muted-foreground mb-4">Try adjusting your search or filter criteria</p>
              <Button
                onClick={() => {
                  setSearchQuery("")
                  setPriceRange([0, 10000])
                  setSelectedCategories([])
                  setSortBy("featured")
                  setActiveFilters([])
                }}
              >
                Reset Filters
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
