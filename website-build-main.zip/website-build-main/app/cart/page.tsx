"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Separator } from "@/components/ui/separator"
import { Minus, Plus, ShoppingCart, Trash2 } from "lucide-react"

// Mock cart data
const cartItems = [
  {
    id: 1,
    name: "Wireless Bluetooth Headphones",
    price: 129.99,
    quantity: 1,
    image: "/placeholder.svg?height=100&width=100",
    discount: 15,
  },
  {
    id: 3,
    name: "Premium Cotton T-Shirt",
    price: 24.99,
    quantity: 2,
    image: "/placeholder.svg?height=100&width=100",
    discount: 0,
  },
]

export default function CartPage() {
  const [items, setItems] = useState(cartItems)
  const [isUrgent, setIsUrgent] = useState(false)
  const [urgentNote, setUrgentNote] = useState("")
  const [couponCode, setCouponCode] = useState("")

  const incrementQuantity = (id: number) => {
    setItems(items.map((item) => (item.id === id ? { ...item, quantity: item.quantity + 1 } : item)))
  }

  const decrementQuantity = (id: number) => {
    setItems(
      items.map((item) => (item.id === id && item.quantity > 1 ? { ...item, quantity: item.quantity - 1 } : item)),
    )
  }

  const removeItem = (id: number) => {
    setItems(items.filter((item) => item.id !== id))
  }

  const calculateSubtotal = () => {
    return items.reduce((total, item) => {
      const discountedPrice = item.discount > 0 ? item.price * (1 - item.discount / 100) : item.price
      return total + discountedPrice * item.quantity
    }, 0)
  }

  const subtotal = calculateSubtotal()
  const shipping = subtotal > 50 ? 0 : 5.99
  const total = subtotal + shipping

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Your Shopping Cart</h1>

      {items.length > 0 ? (
        <div className="flex flex-col lg:flex-row gap-8">
          <div className="lg:w-2/3">
            <div className="rounded-lg border overflow-hidden">
              <table className="w-full">
                <thead className="bg-muted">
                  <tr>
                    <th className="text-left p-4">Product</th>
                    <th className="text-center p-4 hidden md:table-cell">Price</th>
                    <th className="text-center p-4">Quantity</th>
                    <th className="text-right p-4">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {items.map((item) => {
                    const discountedPrice = item.discount > 0 ? item.price * (1 - item.discount / 100) : item.price

                    return (
                      <tr key={item.id} className="border-t">
                        <td className="p-4">
                          <div className="flex items-center gap-4">
                            <div className="relative h-20 w-20 rounded overflow-hidden">
                              <Image
                                src={item.image || "/placeholder.svg"}
                                alt={item.name}
                                fill
                                className="object-cover"
                              />
                            </div>
                            <div>
                              <Link href={`/products/${item.id}`} className="font-medium hover:underline">
                                {item.name}
                              </Link>
                              {item.discount > 0 && <div className="text-sm text-red-600">-{item.discount}% OFF</div>}
                              <div className="md:hidden text-sm mt-1">
                                Rs {discountedPrice.toFixed(2)}
                                {item.discount > 0 && (
                                  <span className="text-muted-foreground line-through ml-2">
                                    Rs {item.price.toFixed(2)}
                                  </span>
                                )}
                              </div>
                              <button
                                className="text-sm text-red-600 flex items-center mt-2 md:hidden"
                                onClick={() => removeItem(item.id)}
                              >
                                <Trash2 className="h-3 w-3 mr-1" />
                                Remove
                              </button>
                            </div>
                          </div>
                        </td>
                        <td className="p-4 text-center hidden md:table-cell">
                          <div>
                            Rs {discountedPrice.toFixed(2)}
                            {item.discount > 0 && (
                              <div className="text-sm text-muted-foreground line-through">
                                Rs {item.price.toFixed(2)}
                              </div>
                            )}
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center justify-center">
                            <div className="flex items-center border rounded-md">
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8"
                                onClick={() => decrementQuantity(item.id)}
                                disabled={item.quantity <= 1}
                              >
                                <Minus className="h-3 w-3" />
                              </Button>
                              <div className="w-10 text-center">{item.quantity}</div>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8"
                                onClick={() => incrementQuantity(item.id)}
                              >
                                <Plus className="h-3 w-3" />
                              </Button>
                            </div>
                          </div>
                        </td>
                        <td className="p-4 text-right">
                          <div className="flex items-center justify-end gap-4">
                            <div className="font-medium">Rs {(discountedPrice * item.quantity).toFixed(2)}</div>
                            <button className="text-red-600 hidden md:block" onClick={() => removeItem(item.id)}>
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>

            <div className="mt-6 flex flex-col sm:flex-row gap-4">
              <div className="flex-1">
                <div className="flex">
                  <Input
                    placeholder="Coupon code"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value)}
                    className="rounded-r-none"
                  />
                  <Button className="rounded-l-none">Apply</Button>
                </div>
              </div>
              <div>
                <Button variant="outline" asChild>
                  <Link href="/products">Continue Shopping</Link>
                </Button>
              </div>
            </div>
          </div>

          <div className="lg:w-1/3">
            <div className="rounded-lg border p-6 space-y-6">
              <h2 className="text-xl font-bold">Order Summary</h2>

              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span>Rs {subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Shipping</span>
                  <span>{shipping === 0 ? "Free" : `Rs ${shipping.toFixed(2)}`}</span>
                </div>
                {shipping > 0 && <div className="text-xs text-muted-foreground">Free shipping on orders over $50</div>}
              </div>

              <Separator />

              <div className="flex justify-between text-lg font-bold">
                <span>Total</span>
                <span>Rs {total.toFixed(2)}</span>
              </div>

              <div className="flex items-start space-x-2 p-4 bg-muted rounded-lg">
                <Checkbox
                  id="urgent-order"
                  checked={isUrgent}
                  onCheckedChange={(checked) => setIsUrgent(checked as boolean)}
                />
                <div className="space-y-1">
                  <Label htmlFor="urgent-order" className="font-medium">
                    Mark as Urgent Order
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    Urgent orders are prioritized and shipped within 24 hours.
                  </p>
                  {isUrgent && (
                    <Textarea
                      placeholder="Add any special instructions for your urgent order..."
                      value={urgentNote}
                      onChange={(e) => setUrgentNote(e.target.value)}
                      className="mt-2"
                    />
                  )}
                </div>
              </div>

              <div className="space-y-4">
                <Button className="w-full" size="lg" asChild>
                  <Link href="/checkout">Proceed to Checkout</Link>
                </Button>

                <div className="flex items-center justify-center text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    Secure checkout powered by
                    <span className="font-medium">Esewa</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="text-center py-16 space-y-6">
          <div className="flex justify-center">
            <ShoppingCart className="h-24 w-24 text-muted-foreground" />
          </div>
          <h2 className="text-2xl font-bold">Your cart is empty</h2>
          <p className="text-muted-foreground max-w-md mx-auto">
            Looks like you haven't added any products to your cart yet. Browse our products and find something you like.
          </p>
          <Button size="lg" asChild>
            <Link href="/products">Start Shopping</Link>
          </Button>
        </div>
      )}
    </div>
  )
}
