"use client"

import { Button } from "@/components/ui/button"

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  return (
    <html>
      <body>
        <div className="flex flex-col items-center justify-center min-h-screen bg-background p-4">
          <div className="text-center space-y-6 max-w-md">
            <div className="space-y-2">
              <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl">Page Not Found</h1>
              <p className="text-muted-foreground">
                We apologize for the inconvenience. Please try again or return to the homepage.
              </p>
            </div>
            <div className="flex justify-center">
              <Button onClick={() => reset()}>Try Again</Button>
            </div>
          </div>
        </div>
      </body>
    </html>
  )
}
