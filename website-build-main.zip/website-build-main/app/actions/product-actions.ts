"use server"

import { revalidatePath } from "next/cache"
import { supabase } from "@/lib/supabase"
import { auth } from "@/lib/firebase-admin"

export async function createProduct(formData: FormData) {
  try {
    const token = formData.get("token") as string

    // Verify the Firebase token
    const decodedToken = await auth.verifyIdToken(token)

    // Check if user is admin
    const { data: userData } = await supabase.from("users").select("is_admin").eq("id", decodedToken.uid).single()

    if (!userData?.is_admin) {
      return { success: false, message: "Unauthorized" }
    }

    const name = formData.get("name") as string
    const slug = (formData.get("slug") as string) || name.toLowerCase().replace(/\s+/g, "-")
    const description = formData.get("description") as string
    const price = Number.parseFloat(formData.get("price") as string)
    const discountPercentage = Number.parseFloat((formData.get("discountPercentage") as string) || "0")
    const stock = Number.parseInt(formData.get("stock") as string)
    const categoryId = formData.get("categoryId") as string
    const isFeatured = formData.get("isFeatured") === "true"
    const isNew = formData.get("isNew") === "true"

    // Create product
    const { data: product, error: productError } = await supabase
      .from("products")
      .insert({
        name,
        slug,
        description,
        price,
        discount_percentage: discountPercentage,
        stock,
        category_id: categoryId,
        is_featured: isFeatured,
        is_new: isNew,
      })
      .select()
      .single()

    if (productError) {
      throw new Error(productError.message)
    }

    // Handle images
    const imageUrls = JSON.parse((formData.get("imageUrls") as string) || "[]")

    if (imageUrls.length > 0) {
      const productImages = imageUrls.map((url: string, index: number) => ({
        product_id: product.id,
        image_url: url,
        is_primary: index === 0,
        display_order: index,
      }))

      const { error: imagesError } = await supabase.from("product_images").insert(productImages)

      if (imagesError) {
        throw new Error(imagesError.message)
      }
    }

    revalidatePath("/admin/products")
    revalidatePath("/products")

    return { success: true, message: "Product created successfully", productId: product.id }
  } catch (error: any) {
    console.error("Error creating product:", error)
    return { success: false, message: error.message || "Failed to create product" }
  }
}

export async function updateProduct(formData: FormData) {
  try {
    const token = formData.get("token") as string
    const productId = formData.get("productId") as string

    // Verify the Firebase token
    const decodedToken = await auth.verifyIdToken(token)

    // Check if user is admin
    const { data: userData } = await supabase.from("users").select("is_admin").eq("id", decodedToken.uid).single()

    if (!userData?.is_admin) {
      return { success: false, message: "Unauthorized" }
    }

    const name = formData.get("name") as string
    const description = formData.get("description") as string
    const price = Number.parseFloat(formData.get("price") as string)
    const discountPercentage = Number.parseFloat((formData.get("discountPercentage") as string) || "0")
    const stock = Number.parseInt(formData.get("stock") as string)
    const categoryId = formData.get("categoryId") as string
    const isFeatured = formData.get("isFeatured") === "true"
    const isNew = formData.get("isNew") === "true"

    // Update product
    const { error: productError } = await supabase
      .from("products")
      .update({
        name,
        description,
        price,
        discount_percentage: discountPercentage,
        stock,
        category_id: categoryId,
        is_featured: isFeatured,
        is_new: isNew,
      })
      .eq("id", productId)

    if (productError) {
      throw new Error(productError.message)
    }

    // Handle new images
    const newImageUrls = JSON.parse((formData.get("newImageUrls") as string) || "[]")

    if (newImageUrls.length > 0) {
      // Get current image count
      const { data: currentImages } = await supabase
        .from("product_images")
        .select("display_order")
        .eq("product_id", productId)
        .order("display_order", { ascending: false })
        .limit(1)

      const startOrder = currentImages && currentImages.length > 0 ? currentImages[0].display_order + 1 : 0

      const productImages = newImageUrls.map((url: string, index: number) => ({
        product_id: productId,
        image_url: url,
        is_primary: currentImages && currentImages.length === 0 && index === 0,
        display_order: startOrder + index,
      }))

      const { error: imagesError } = await supabase.from("product_images").insert(productImages)

      if (imagesError) {
        throw new Error(imagesError.message)
      }
    }

    revalidatePath("/admin/products")
    revalidatePath(`/products/${productId}`)
    revalidatePath("/products")

    return { success: true, message: "Product updated successfully" }
  } catch (error: any) {
    console.error("Error updating product:", error)
    return { success: false, message: error.message || "Failed to update product" }
  }
}

export async function deleteProduct(productId: string, token: string) {
  try {
    // Verify the Firebase token
    const decodedToken = await auth.verifyIdToken(token)

    // Check if user is admin
    const { data: userData } = await supabase.from("users").select("is_admin").eq("id", decodedToken.uid).single()

    if (!userData?.is_admin) {
      return { success: false, message: "Unauthorized" }
    }

    // Delete product (will cascade delete images)
    const { error } = await supabase.from("products").delete().eq("id", productId)

    if (error) {
      throw new Error(error.message)
    }

    revalidatePath("/admin/products")
    revalidatePath("/products")

    return { success: true, message: "Product deleted successfully" }
  } catch (error: any) {
    console.error("Error deleting product:", error)
    return { success: false, message: error.message || "Failed to delete product" }
  }
}
