"use server"

import { revalidatePath } from "next/cache"
import { redirect } from "next/navigation"
import { verifyAdminCredentials, setAdminSession, clearAdminSession, hashPassword } from "@/lib/admin-auth"
import { createServerClient } from "@/lib/supabase-server"

// Admin login action
export async function adminLogin(formData: FormData) {
  const email = formData.get("email") as string
  const password = formData.get("password") as string

  if (!email || !password) {
    return { success: false, message: "Email and password are required" }
  }

  const result = await verifyAdminCredentials(email, password)

  if (!result.success) {
    return result
  }

  // Set admin session
  setAdminSession(result.adminId)

  return { success: true, message: "Login successful" }
}

// Admin logout action
export async function adminLogout() {
  clearAdminSession()
  redirect("/admin/login")
}

// Change admin password
export async function changeAdminPassword(formData: FormData) {
  const currentPassword = formData.get("currentPassword") as string
  const newPassword = formData.get("newPassword") as string
  const confirmPassword = formData.get("confirmPassword") as string

  if (!currentPassword || !newPassword || !confirmPassword) {
    return { success: false, message: "All fields are required" }
  }

  if (newPassword !== confirmPassword) {
    return { success: false, message: "New passwords do not match" }
  }

  // Minimum password requirements
  if (newPassword.length < 8) {
    return { success: false, message: "Password must be at least 8 characters long" }
  }

  const supabase = createServerClient()

  // Get admin email from users table
  const { data: adminUser } = await supabase.from("users").select("email").eq("is_admin", true).single()

  if (!adminUser) {
    return { success: false, message: "Admin user not found" }
  }

  // Verify current password
  const verifyResult = await verifyAdminCredentials(adminUser.email, currentPassword)

  if (!verifyResult.success) {
    return { success: false, message: "Current password is incorrect" }
  }

  // Update password
  const hashedPassword = hashPassword(newPassword)

  const { error } = await supabase
    .from("admin_credentials")
    .update({ password_hash: hashedPassword })
    .eq("email", adminUser.email)

  if (error) {
    console.error("Error updating admin password:", error)
    return { success: false, message: "Failed to update password" }
  }

  revalidatePath("/admin/settings")

  return { success: true, message: "Password updated successfully" }
}
