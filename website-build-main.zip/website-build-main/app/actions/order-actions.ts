"use server"

import { revalidatePath } from "next/cache"
import { supabase } from "@/lib/supabase"
import { auth } from "@/lib/firebase-admin"

export async function createOrder(formData: FormData) {
  try {
    const token = formData.get("token") as string

    // Verify the Firebase token
    const decodedToken = await auth.verifyIdToken(token)
    const userId = decodedToken.uid

    // Get cart items
    const { data: cartItems } = await supabase
      .from("cart_items")
      .select(`
        *,
        product:products(*)
      `)
      .eq("user_id", userId)

    if (!cartItems || cartItems.length === 0) {
      return { success: false, message: "Cart is empty" }
    }

    // Calculate total
    const totalAmount = cartItems.reduce((total, item) => {
      const price = item.product.price
      const discountedPrice = price * (1 - item.product.discount_percentage / 100)
      return total + discountedPrice * item.quantity
    }, 0)

    // Create order
    const orderNumber = `ORD-${Math.floor(100000 + Math.random() * 900000)}`
    const shippingAddressId = formData.get("addressId") as string
    const paymentMethod = formData.get("paymentMethod") as string
    const isUrgent = formData.get("isUrgent") === "true"
    const urgentNote = formData.get("urgentNote") as string

    const { data: order, error: orderError } = await supabase
      .from("orders")
      .insert({
        user_id: userId,
        order_number: orderNumber,
        status: "processing",
        total_amount: totalAmount,
        shipping_address_id: shippingAddressId,
        payment_method: paymentMethod,
        is_urgent: isUrgent,
        urgent_note: urgentNote,
      })
      .select()
      .single()

    if (orderError) {
      throw new Error(orderError.message)
    }

    // Create order items
    const orderItems = cartItems.map((item) => ({
      order_id: order.id,
      product_id: item.product.id,
      quantity: item.quantity,
      price: item.product.price * (1 - item.product.discount_percentage / 100),
    }))

    const { error: itemsError } = await supabase.from("order_items").insert(orderItems)

    if (itemsError) {
      throw new Error(itemsError.message)
    }

    // Clear cart
    await supabase.from("cart_items").delete().eq("user_id", userId)

    revalidatePath("/cart")
    revalidatePath("/dashboard/orders")

    return {
      success: true,
      message: "Order placed successfully",
      orderId: order.id,
      orderNumber,
    }
  } catch (error: any) {
    console.error("Error creating order:", error)
    return { success: false, message: error.message || "Failed to create order" }
  }
}

export async function updateOrderStatus(orderId: string, status: string) {
  try {
    const { error } = await supabase.from("orders").update({ status }).eq("id", orderId)

    if (error) {
      throw new Error(error.message)
    }

    revalidatePath("/admin/orders")
    revalidatePath("/dashboard/orders")

    return { success: true, message: "Order status updated successfully" }
  } catch (error: any) {
    console.error("Error updating order status:", error)
    return { success: false, message: error.message || "Failed to update order status" }
  }
}
