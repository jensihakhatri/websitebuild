"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ShoppingCart, Trash2, Heart } from "lucide-react"

// Mock data
const wishlistItems = [
  {
    id: 1,
    name: "Wireless Bluetooth Headphones",
    price: 12999,
    rating: 4.5,
    image: "/placeholder.svg?height=200&width=200",
    category: "Electronics",
    isNew: true,
    discount: 15,
    inStock: true,
  },
  {
    id: 2,
    name: "Smart Watch Series 5",
    price: 19999,
    rating: 4.8,
    image: "/placeholder.svg?height=200&width=200",
    category: "Electronics",
    isNew: true,
    discount: 0,
    inStock: true,
  },
  {
    id: 5,
    name: 'Ultra HD 4K Smart TV - 55"',
    price: 69999,
    rating: 4.7,
    image: "/placeholder.svg?height=200&width=200",
    category: "Electronics",
    isNew: false,
    discount: 30,
    inStock: false,
  },
]

export default function WishlistPage() {
  const [items, setItems] = useState(wishlistItems)

  const removeItem = (id: number) => {
    setItems(items.filter((item) => item.id !== id))
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">My Wishlist</h1>

      {items.length > 0 ? (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {items.map((item) => {
              const discountedPrice = item.discount > 0 ? item.price * (1 - item.discount / 100) : item.price

              return (
                <Card key={item.id} className="overflow-hidden">
                  <div className="relative">
                    <div className="relative h-[200px] w-full">
                      <Image src={item.image || "/placeholder.svg"} alt={item.name} fill className="object-contain" />
                    </div>

                    <button
                      className="absolute top-2 right-2 h-8 w-8 rounded-full bg-background/80 flex items-center justify-center text-red-500 hover:bg-background"
                      onClick={() => removeItem(item.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>

                    {item.isNew && <Badge className="absolute top-2 left-2">New</Badge>}

                    {item.discount > 0 && (
                      <Badge variant="destructive" className="absolute bottom-2 left-2">
                        {item.discount}% OFF
                      </Badge>
                    )}
                  </div>

                  <CardContent className="p-4">
                    <div className="text-sm text-muted-foreground mb-1">{item.category}</div>
                    <Link href={`/products/${item.id}`} className="hover:underline">
                      <h3 className="font-semibold text-lg line-clamp-2 mb-1">{item.name}</h3>
                    </Link>

                    <div className="flex items-center mb-2">
                      {Array(5)
                        .fill(0)
                        .map((_, i) => (
                          <svg
                            key={i}
                            className={`h-4 w-4 ${
                              i < Math.floor(item.rating)
                                ? "text-yellow-400 fill-yellow-400"
                                : i < item.rating
                                  ? "text-yellow-400 fill-yellow-400 opacity-50"
                                  : "text-gray-300"
                            }`}
                            xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 24 24"
                          >
                            <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                          </svg>
                        ))}
                      <span className="text-xs text-muted-foreground ml-1">({item.rating})</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        {item.discount > 0 ? (
                          <div className="flex items-center">
                            <span className="font-bold text-lg">Rs {Math.round(discountedPrice).toLocaleString()}</span>
                            <span className="text-muted-foreground line-through ml-2">
                              Rs {item.price.toLocaleString()}
                            </span>
                          </div>
                        ) : (
                          <span className="font-bold text-lg">Rs {item.price.toLocaleString()}</span>
                        )}
                      </div>

                      <Button variant="outline" size="sm" className="flex items-center gap-1" disabled={!item.inStock}>
                        <ShoppingCart className="h-4 w-4" />
                        {item.inStock ? "Add to Cart" : "Out of Stock"}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      ) : (
        <div className="text-center py-16 space-y-6">
          <div className="flex justify-center">
            <Heart className="h-24 w-24 text-muted-foreground" />
          </div>
          <h2 className="text-2xl font-bold">Your wishlist is empty</h2>
          <p className="text-muted-foreground max-w-md mx-auto">
            You haven't added any products to your wishlist yet. Browse our products and find something you like.
          </p>
          <Button size="lg" asChild>
            <Link href="/products">Start Shopping</Link>
          </Button>
        </div>
      )}
    </div>
  )
}
