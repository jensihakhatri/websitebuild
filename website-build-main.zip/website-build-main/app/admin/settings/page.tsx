import { redirect } from "next/navigation"
import { isAdminAuthenticated } from "@/lib/admin-auth"
import { AdminLayout } from "@/components/admin/admin-layout"
import { AdminSettings } from "@/components/admin/settings"

export default async function AdminSettingsPage() {
  // Check if user is authenticated as admin
  const isAdmin = await isAdminAuthenticated()

  if (!isAdmin) {
    redirect("/admin/login")
  }

  return (
    <AdminLayout>
      <h2 className="text-2xl font-bold mb-6">Admin Settings</h2>
      <AdminSettings />
    </AdminLayout>
  )
}
