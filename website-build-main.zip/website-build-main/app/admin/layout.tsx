import type React from "react"
import "@/app/admin-theme.css"

export default function AdminRootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <>{children}</>
}
