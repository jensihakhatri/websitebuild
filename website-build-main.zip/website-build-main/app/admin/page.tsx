"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { isAdmin } from "@/lib/admin-auth"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BarChart, Users, Package, ShoppingCart, Settings, LogOut } from "lucide-react"
import { AdminDashboard } from "@/components/admin/dashboard"
import { AdminProducts } from "@/components/admin/products"
import { AdminOrders } from "@/components/admin/orders"
import { AdminUsers } from "@/components/admin/users"
import { AdminSettings } from "@/components/admin/settings"

export default function AdminPage() {
  const [loading, setLoading] = useState(true)
  const [authenticated, setAuthenticated] = useState(false)
  const router = useRouter()

  useEffect(() => {
    const checkAuth = async () => {
      const auth = await isAdmin()
      setAuthenticated(auth)
      setLoading(false)

      if (!auth) {
        router.push("/admin/login")
      }
    }

    checkAuth()
  }, [router])

  const handleLogout = async () => {
    document.cookie = "admin_session=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT"
    router.push("/admin/login")
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-[#0a0e17]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    )
  }

  if (!authenticated) {
    return null // Will redirect in useEffect
  }

  return (
    <div className="min-h-screen bg-[#0a0e17] text-white">
      <div className="flex flex-col md:flex-row">
        {/* Sidebar */}
        <div className="w-full md:w-64 bg-[#0f1623] p-4 md:min-h-screen">
          <div className="flex items-center gap-2 mb-8">
            <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center">
              <span className="text-primary font-bold">N</span>
            </div>
            <h1 className="text-xl font-bold">NepalMart Admin</h1>
          </div>

          <nav className="space-y-2">
            <TabsList className="flex flex-col w-full h-auto bg-transparent space-y-1">
              <TabsTrigger value="dashboard" className="w-full justify-start">
                <BarChart className="mr-2 h-4 w-4" />
                Dashboard
              </TabsTrigger>
              <TabsTrigger value="products" className="w-full justify-start">
                <Package className="mr-2 h-4 w-4" />
                Products
              </TabsTrigger>
              <TabsTrigger value="orders" className="w-full justify-start">
                <ShoppingCart className="mr-2 h-4 w-4" />
                Orders
              </TabsTrigger>
              <TabsTrigger value="users" className="w-full justify-start">
                <Users className="mr-2 h-4 w-4" />
                Users
              </TabsTrigger>
              <TabsTrigger value="settings" className="w-full justify-start">
                <Settings className="mr-2 h-4 w-4" />
                Settings
              </TabsTrigger>
            </TabsList>

            <Button variant="ghost" className="w-full justify-start text-red-400" onClick={handleLogout}>
              <LogOut className="mr-2 h-4 w-4" />
              Logout
            </Button>
          </nav>
        </div>

        {/* Main content */}
        <div className="flex-1 p-4">
          <Tabs defaultValue="dashboard" className="w-full">
            <TabsContent value="dashboard" className="mt-0">
              <AdminDashboard />
            </TabsContent>
            <TabsContent value="products" className="mt-0">
              <AdminProducts />
            </TabsContent>
            <TabsContent value="orders" className="mt-0">
              <AdminOrders />
            </TabsContent>
            <TabsContent value="users" className="mt-0">
              <AdminUsers />
            </TabsContent>
            <TabsContent value="settings" className="mt-0">
              <AdminSettings />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
