"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card } from "@/components/ui/card"
import { UserLogin } from "@/components/auth/user-login"
import { UserRegister } from "@/components/auth/user-register"
import { AdminLogin } from "@/components/auth/admin-login"
import { ShieldCheck, UserPlus, User } from "lucide-react"

export default function AuthPage() {
  const [activeTab, setActiveTab] = useState("login")

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background to-secondary/10 p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-cyan-500 to-blue-500">
            NepalMart Account
          </h1>
          <p className="text-muted-foreground mt-2">Sign in or create an account to continue</p>
        </div>

        <Card className="border border-secondary/20 bg-background/80 backdrop-blur-sm shadow-xl">
          <Tabs defaultValue="login" value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-3 w-full rounded-b-none bg-muted/50">
              <TabsTrigger value="login" className="data-[state=active]:bg-background rounded-b-none">
                <User className="h-4 w-4 mr-2" />
                Login
              </TabsTrigger>
              <TabsTrigger value="register" className="data-[state=active]:bg-background rounded-b-none">
                <UserPlus className="h-4 w-4 mr-2" />
                Register
              </TabsTrigger>
              <TabsTrigger value="admin" className="data-[state=active]:bg-background rounded-b-none">
                <ShieldCheck className="h-4 w-4 mr-2" />
                Admin
              </TabsTrigger>
            </TabsList>
            <TabsContent value="login" className="m-0">
              <UserLogin onRegisterClick={() => setActiveTab("register")} />
            </TabsContent>
            <TabsContent value="register" className="m-0">
              <UserRegister onLoginClick={() => setActiveTab("login")} />
            </TabsContent>
            <TabsContent value="admin" className="m-0">
              <AdminLogin />
            </TabsContent>
          </Tabs>
        </Card>

        <div className="text-center mt-6">
          <p className="text-xs text-muted-foreground">
            Protected by NepalMart Security &bull; {new Date().getFullYear()}
          </p>
        </div>
      </div>
    </div>
  )
}
