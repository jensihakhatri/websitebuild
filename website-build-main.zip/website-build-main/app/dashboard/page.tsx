"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { useAuth } from "@/components/auth-provider"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { LoadingSpinner } from "@/components/loading-spinner"
import { Clock, Package, Settings, ShoppingBag, User } from "lucide-react"

export default function DashboardPage() {
  const { user, loading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!loading && !user) {
      router.push("/auth/login")
    }
  }, [user, loading, router])

  if (loading) {
    return <LoadingSpinner />
  }

  if (!user) {
    return null
  }

  // Mock data
  const recentOrders = [
    {
      id: "ORD-1001",
      date: "2023-05-15",
      total: 149.98,
      status: "Processing",
      items: [
        {
          id: 1,
          name: "Wireless Bluetooth Headphones",
          price: 129.99,
          quantity: 1,
          image: "/placeholder.svg?height=50&width=50",
        },
        {
          id: 3,
          name: "Premium Cotton T-Shirt",
          price: 24.99,
          quantity: 1,
          image: "/placeholder.svg?height=50&width=50",
        },
      ],
    },
    {
      id: "ORD-1002",
      date: "2023-05-10",
      total: 199.99,
      status: "Shipped",
      items: [
        {
          id: 2,
          name: "Smart Watch Series 5",
          price: 199.99,
          quantity: 1,
          image: "/placeholder.svg?height=50&width=50",
        },
      ],
    },
    {
      id: "ORD-1003",
      date: "2023-05-01",
      total: 39.98,
      status: "Delivered",
      items: [
        {
          id: 4,
          name: "Stainless Steel Water Bottle",
          price: 19.99,
          quantity: 2,
          image: "/placeholder.svg?height=50&width=50",
        },
      ],
    },
  ]

  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case "processing":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            Processing
          </Badge>
        )
      case "shipped":
        return (
          <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
            Shipped
          </Badge>
        )
      case "delivered":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Delivered
          </Badge>
        )
      default:
        return <Badge variant="outline">Unknown</Badge>
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row gap-8">
        <div className="md:w-1/4">
          <div className="sticky top-20 space-y-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center">
                  <div className="h-24 w-24 relative rounded-full overflow-hidden mb-4">
                    <Image
                      src="/placeholder.svg?height=100&width=100"
                      alt={user.displayName || "User"}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <h2 className="text-xl font-bold">{user.displayName || "User"}</h2>
                  <p className="text-sm text-muted-foreground">{user.email}</p>
                </div>
              </CardContent>
            </Card>

            <div className="bg-background rounded-lg border overflow-hidden">
              <nav className="flex flex-col">
                <Link href="/dashboard" className="flex items-center gap-2 px-4 py-3 bg-muted font-medium">
                  <ShoppingBag className="h-5 w-5" />
                  Dashboard
                </Link>
                <Link href="/dashboard/orders" className="flex items-center gap-2 px-4 py-3 hover:bg-muted">
                  <Package className="h-5 w-5" />
                  Orders
                </Link>
                <Link href="/dashboard/profile" className="flex items-center gap-2 px-4 py-3 hover:bg-muted">
                  <User className="h-5 w-5" />
                  Profile
                </Link>
                <Link href="/dashboard/settings" className="flex items-center gap-2 px-4 py-3 hover:bg-muted">
                  <Settings className="h-5 w-5" />
                  Settings
                </Link>
              </nav>
            </div>
          </div>
        </div>

        <div className="md:w-3/4">
          <h1 className="text-3xl font-bold mb-6">Dashboard</h1>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{recentOrders.length}</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Spent</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  ${recentOrders.reduce((total, order) => total + order.total, 0).toFixed(2)}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Active Orders</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {recentOrders.filter((order) => order.status !== "Delivered").length}
                </div>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="orders" className="space-y-6">
            <TabsList>
              <TabsTrigger value="orders">Recent Orders</TabsTrigger>
              <TabsTrigger value="activity">Account Activity</TabsTrigger>
            </TabsList>

            <TabsContent value="orders">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Orders</CardTitle>
                  <CardDescription>View and manage your recent orders.</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {recentOrders.map((order) => (
                      <div key={order.id} className="border rounded-lg overflow-hidden">
                        <div className="bg-muted p-4 flex flex-col sm:flex-row justify-between gap-4">
                          <div>
                            <div className="flex items-center gap-2">
                              <h3 className="font-medium">{order.id}</h3>
                              {getStatusBadge(order.status)}
                            </div>
                            <p className="text-sm text-muted-foreground">
                              Placed on {new Date(order.date).toLocaleDateString()}
                            </p>
                          </div>
                          <div className="flex items-center gap-4">
                            <div className="text-right">
                              <div className="font-medium">${order.total.toFixed(2)}</div>
                              <div className="text-sm text-muted-foreground">
                                {order.items.reduce((total, item) => total + item.quantity, 0)} items
                              </div>
                            </div>
                            <Button variant="outline" size="sm" asChild>
                              <Link href={`/dashboard/orders/${order.id}`}>View</Link>
                            </Button>
                          </div>
                        </div>

                        <div className="p-4">
                          <div className="flex flex-wrap gap-4">
                            {order.items.map((item) => (
                              <div key={item.id} className="flex items-center gap-3">
                                <div className="relative h-12 w-12 rounded overflow-hidden">
                                  <Image
                                    src={item.image || "/placeholder.svg"}
                                    alt={item.name}
                                    fill
                                    className="object-cover"
                                  />
                                </div>
                                <div>
                                  <div className="font-medium line-clamp-1">{item.name}</div>
                                  <div className="text-sm text-muted-foreground">
                                    ${item.price.toFixed(2)} x {item.quantity}
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))}

                    <div className="flex justify-center">
                      <Button variant="outline" asChild>
                        <Link href="/dashboard/orders">View All Orders</Link>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="activity">
              <Card>
                <CardHeader>
                  <CardTitle>Account Activity</CardTitle>
                  <CardDescription>Recent activity on your account.</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-start gap-4">
                      <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
                        <Clock className="h-4 w-4 text-blue-600" />
                      </div>
                      <div>
                        <div className="font-medium">Login from new device</div>
                        <div className="text-sm text-muted-foreground">
                          You logged in from a new device on May 15, 2023
                        </div>
                      </div>
                    </div>

                    <Separator />

                    <div className="flex items-start gap-4">
                      <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0">
                        <ShoppingBag className="h-4 w-4 text-green-600" />
                      </div>
                      <div>
                        <div className="font-medium">Order placed</div>
                        <div className="text-sm text-muted-foreground">You placed order #ORD-1001 on May 15, 2023</div>
                      </div>
                    </div>

                    <Separator />

                    <div className="flex items-start gap-4">
                      <div className="h-8 w-8 rounded-full bg-yellow-100 flex items-center justify-center flex-shrink-0">
                        <User className="h-4 w-4 text-yellow-600" />
                      </div>
                      <div>
                        <div className="font-medium">Profile updated</div>
                        <div className="text-sm text-muted-foreground">
                          You updated your profile information on May 10, 2023
                        </div>
                      </div>
                    </div>

                    <Separator />

                    <div className="flex items-start gap-4">
                      <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0">
                        <ShoppingBag className="h-4 w-4 text-green-600" />
                      </div>
                      <div>
                        <div className="font-medium">Order placed</div>
                        <div className="text-sm text-muted-foreground">You placed order #ORD-1002 on May 10, 2023</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
