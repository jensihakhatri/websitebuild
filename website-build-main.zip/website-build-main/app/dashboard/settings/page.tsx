"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { useAuth } from "@/components/auth-provider"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/components/ui/use-toast"
import { LoadingSpinner } from "@/components/loading-spinner"
import { Bell, Globe, Package, ShoppingBag, User, Settings } from "lucide-react"

export default function SettingsPage() {
  const { user, loading } = useAuth()
  const router = useRouter()
  const { toast } = useToast()

  const [settings, setSettings] = useState({
    emailNotifications: true,
    orderUpdates: true,
    promotions: false,
    newsletter: false,
    darkMode: false,
    savePaymentInfo: true,
    saveShippingInfo: true,
    showRecentlyViewed: true,
    language: "english",
    currency: "usd",
  })

  const [isSubmitting, setIsSubmitting] = useState(false)

  useEffect(() => {
    if (!loading && !user) {
      router.push("/auth/login")
    }
  }, [user, loading, router])

  if (loading) {
    return <LoadingSpinner />
  }

  if (!user) {
    return null
  }

  const handleToggle = (setting: string) => {
    setSettings({
      ...settings,
      [setting]: !settings[setting as keyof typeof settings],
    })
  }

  const handleSaveSettings = () => {
    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false)

      toast({
        title: "Settings Saved",
        description: "Your preferences have been updated successfully.",
      })
    }, 1500)
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row gap-8">
        <div className="md:w-1/4">
          <div className="sticky top-20 space-y-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center">
                  <div className="h-24 w-24 relative rounded-full overflow-hidden mb-4">
                    <Image
                      src="/placeholder.svg?height=100&width=100"
                      alt={user.displayName || "User"}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <h2 className="text-xl font-bold">{user.displayName || "User"}</h2>
                  <p className="text-sm text-muted-foreground">{user.email}</p>
                </div>
              </CardContent>
            </Card>

            <div className="bg-background rounded-lg border overflow-hidden">
              <nav className="flex flex-col">
                <Link href="/dashboard" className="flex items-center gap-2 px-4 py-3 hover:bg-muted">
                  <ShoppingBag className="h-5 w-5" />
                  Dashboard
                </Link>
                <Link href="/dashboard/orders" className="flex items-center gap-2 px-4 py-3 hover:bg-muted">
                  <Package className="h-5 w-5" />
                  Orders
                </Link>
                <Link href="/dashboard/profile" className="flex items-center gap-2 px-4 py-3 hover:bg-muted">
                  <User className="h-5 w-5" />
                  Profile
                </Link>
                <Link href="/dashboard/settings" className="flex items-center gap-2 px-4 py-3 bg-muted font-medium">
                  <Settings className="h-5 w-5" />
                  Settings
                </Link>
              </nav>
            </div>
          </div>
        </div>

        <div className="md:w-3/4">
          <h1 className="text-3xl font-bold mb-6">Account Settings</h1>

          <Tabs defaultValue="notifications">
            <TabsList>
              <TabsTrigger value="notifications">Notifications</TabsTrigger>
              <TabsTrigger value="preferences">Preferences</TabsTrigger>
              <TabsTrigger value="privacy">Privacy</TabsTrigger>
            </TabsList>

            <TabsContent value="notifications" className="space-y-6 mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Email Notifications</CardTitle>
                  <CardDescription>Manage the emails you want to receive.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="emailNotifications">Email Notifications</Label>
                        <p className="text-sm text-muted-foreground">Receive emails about your account activity.</p>
                      </div>
                      <Switch
                        id="emailNotifications"
                        checked={settings.emailNotifications}
                        onCheckedChange={() => handleToggle("emailNotifications")}
                      />
                    </div>

                    <Separator />

                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="orderUpdates">Order Updates</Label>
                        <p className="text-sm text-muted-foreground">Receive emails about your order status changes.</p>
                      </div>
                      <Switch
                        id="orderUpdates"
                        checked={settings.orderUpdates}
                        onCheckedChange={() => handleToggle("orderUpdates")}
                      />
                    </div>

                    <Separator />

                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="promotions">Promotions</Label>
                        <p className="text-sm text-muted-foreground">Receive emails about promotions and discounts.</p>
                      </div>
                      <Switch
                        id="promotions"
                        checked={settings.promotions}
                        onCheckedChange={() => handleToggle("promotions")}
                      />
                    </div>

                    <Separator />

                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="newsletter">Newsletter</Label>
                        <p className="text-sm text-muted-foreground">
                          Receive our weekly newsletter with new products and trends.
                        </p>
                      </div>
                      <Switch
                        id="newsletter"
                        checked={settings.newsletter}
                        onCheckedChange={() => handleToggle("newsletter")}
                      />
                    </div>
                  </div>

                  <Button onClick={handleSaveSettings} disabled={isSubmitting}>
                    {isSubmitting ? "Saving..." : "Save Changes"}
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Push Notifications</CardTitle>
                  <CardDescription>Configure push notifications for the mobile app.</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Push Notifications</Label>
                      <p className="text-sm text-muted-foreground">Enable push notifications in our mobile app.</p>
                    </div>
                    <Button variant="outline">
                      <Bell className="h-4 w-4 mr-2" />
                      Configure in App
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="preferences" className="space-y-6 mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Appearance</CardTitle>
                  <CardDescription>Customize how the website looks for you.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="darkMode">Dark Mode</Label>
                      <p className="text-sm text-muted-foreground">Switch between light and dark theme.</p>
                    </div>
                    <Switch
                      id="darkMode"
                      checked={settings.darkMode}
                      onCheckedChange={() => handleToggle("darkMode")}
                    />
                  </div>

                  <Separator />

                  <div className="space-y-4">
                    <div className="space-y-0.5">
                      <Label>Language</Label>
                      <p className="text-sm text-muted-foreground">Select your preferred language.</p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <Button
                        variant={settings.language === "english" ? "default" : "outline"}
                        onClick={() => setSettings({ ...settings, language: "english" })}
                        className="flex items-center gap-2"
                      >
                        <Globe className="h-4 w-4" />
                        English
                      </Button>
                      <Button
                        variant={settings.language === "nepali" ? "default" : "outline"}
                        onClick={() => setSettings({ ...settings, language: "nepali" })}
                        className="flex items-center gap-2"
                      >
                        <Globe className="h-4 w-4" />
                        Nepali
                      </Button>
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-4">
                    <div className="space-y-0.5">
                      <Label>Currency</Label>
                      <p className="text-sm text-muted-foreground">Select your preferred currency.</p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <Button
                        variant={settings.currency === "usd" ? "default" : "outline"}
                        onClick={() => setSettings({ ...settings, currency: "usd" })}
                      >
                        USD ($)
                      </Button>
                      <Button
                        variant={settings.currency === "npr" ? "default" : "outline"}
                        onClick={() => setSettings({ ...settings, currency: "npr" })}
                      >
                        NPR (रू)
                      </Button>
                    </div>
                  </div>

                  <Button onClick={handleSaveSettings} disabled={isSubmitting}>
                    {isSubmitting ? "Saving..." : "Save Changes"}
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="privacy" className="space-y-6 mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Privacy Settings</CardTitle>
                  <CardDescription>Manage how your information is used.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="savePaymentInfo">Save Payment Information</Label>
                        <p className="text-sm text-muted-foreground">
                          Securely save your payment methods for faster checkout.
                        </p>
                      </div>
                      <Switch
                        id="savePaymentInfo"
                        checked={settings.savePaymentInfo}
                        onCheckedChange={() => handleToggle("savePaymentInfo")}
                      />
                    </div>

                    <Separator />

                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="saveShippingInfo">Save Shipping Information</Label>
                        <p className="text-sm text-muted-foreground">
                          Save your shipping addresses for faster checkout.
                        </p>
                      </div>
                      <Switch
                        id="saveShippingInfo"
                        checked={settings.saveShippingInfo}
                        onCheckedChange={() => handleToggle("saveShippingInfo")}
                      />
                    </div>

                    <Separator />

                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="showRecentlyViewed">Recently Viewed Products</Label>
                        <p className="text-sm text-muted-foreground">Track and display recently viewed products.</p>
                      </div>
                      <Switch
                        id="showRecentlyViewed"
                        checked={settings.showRecentlyViewed}
                        onCheckedChange={() => handleToggle("showRecentlyViewed")}
                      />
                    </div>
                  </div>

                  <Button onClick={handleSaveSettings} disabled={isSubmitting}>
                    {isSubmitting ? "Saving..." : "Save Changes"}
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Data & Privacy</CardTitle>
                  <CardDescription>Manage your personal data.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium">Download Your Data</h3>
                        <p className="text-sm text-muted-foreground">Get a copy of your personal data.</p>
                      </div>
                      <Button variant="outline">Request Data</Button>
                    </div>

                    <Separator />

                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium">Browsing History</h3>
                        <p className="text-sm text-muted-foreground">Clear your browsing history on this device.</p>
                      </div>
                      <Button variant="outline">Clear History</Button>
                    </div>

                    <Separator />

                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium text-red-500">Delete Account</h3>
                        <p className="text-sm text-muted-foreground">Permanently delete your account and all data.</p>
                      </div>
                      <Button variant="destructive">Delete Account</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
