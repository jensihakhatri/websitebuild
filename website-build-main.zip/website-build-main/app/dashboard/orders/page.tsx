"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { useAuth } from "@/components/auth-provider"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { LoadingSpinner } from "@/components/loading-spinner"
import { Clock, Package, Search, ShoppingBag, Truck, User, Settings } from "lucide-react"

// Mock data
const orders = [
  {
    id: "ORD-1001",
    date: "2023-05-15",
    total: 149.98,
    status: "Processing",
    items: [
      {
        id: 1,
        name: "Wireless Bluetooth Headphones",
        price: 129.99,
        quantity: 1,
        image: "/placeholder.svg?height=50&width=50",
      },
      {
        id: 3,
        name: "Premium Cotton T-Shirt",
        price: 24.99,
        quantity: 1,
        image: "/placeholder.svg?height=50&width=50",
      },
    ],
    isUrgent: true,
  },
  {
    id: "ORD-1002",
    date: "2023-05-10",
    total: 199.99,
    status: "Shipped",
    items: [
      {
        id: 2,
        name: "Smart Watch Series 5",
        price: 199.99,
        quantity: 1,
        image: "/placeholder.svg?height=50&width=50",
      },
    ],
    isUrgent: false,
  },
  {
    id: "ORD-1003",
    date: "2023-05-01",
    total: 39.98,
    status: "Delivered",
    items: [
      {
        id: 4,
        name: "Stainless Steel Water Bottle",
        price: 19.99,
        quantity: 2,
        image: "/placeholder.svg?height=50&width=50",
      },
    ],
    isUrgent: false,
  },
]

export default function OrdersPage() {
  const { user, loading } = useAuth()
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")

  useEffect(() => {
    if (!loading && !user) {
      router.push("/auth/login")
    }
  }, [user, loading, router])

  if (loading) {
    return <LoadingSpinner />
  }

  if (!user) {
    return null
  }

  // Filter orders based on search query
  const filteredOrders = orders.filter((order) => {
    return (
      order.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.items.some((item) => item.name.toLowerCase().includes(searchQuery.toLowerCase()))
    )
  })

  const getStatusIcon = (status: string) => {
    switch (status.toLowerCase()) {
      case "processing":
        return <Clock className="h-5 w-5 text-blue-500" />
      case "shipped":
        return <Truck className="h-5 w-5 text-yellow-500" />
      case "delivered":
        return <Package className="h-5 w-5 text-green-500" />
      default:
        return <ShoppingBag className="h-5 w-5" />
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case "processing":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            Processing
          </Badge>
        )
      case "shipped":
        return (
          <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
            Shipped
          </Badge>
        )
      case "delivered":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Delivered
          </Badge>
        )
      default:
        return <Badge variant="outline">Unknown</Badge>
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row gap-8">
        <div className="md:w-1/4">
          <div className="sticky top-20 space-y-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center">
                  <div className="h-24 w-24 relative rounded-full overflow-hidden mb-4">
                    <Image
                      src="/placeholder.svg?height=100&width=100"
                      alt={user.displayName || "User"}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <h2 className="text-xl font-bold">{user.displayName || "User"}</h2>
                  <p className="text-sm text-muted-foreground">{user.email}</p>
                </div>
              </CardContent>
            </Card>

            <div className="bg-background rounded-lg border overflow-hidden">
              <nav className="flex flex-col">
                <Link href="/dashboard" className="flex items-center gap-2 px-4 py-3 hover:bg-muted">
                  <ShoppingBag className="h-5 w-5" />
                  Dashboard
                </Link>
                <Link href="/dashboard/orders" className="flex items-center gap-2 px-4 py-3 bg-muted font-medium">
                  <Package className="h-5 w-5" />
                  Orders
                </Link>
                <Link href="/dashboard/profile" className="flex items-center gap-2 px-4 py-3 hover:bg-muted">
                  <User className="h-5 w-5" />
                  Profile
                </Link>
                <Link href="/dashboard/settings" className="flex items-center gap-2 px-4 py-3 hover:bg-muted">
                  <Settings className="h-5 w-5" />
                  Settings
                </Link>
              </nav>
            </div>
          </div>
        </div>

        <div className="md:w-3/4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
            <h1 className="text-3xl font-bold">My Orders</h1>

            <div className="relative w-full sm:w-[300px] mt-4 sm:mt-0">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search orders..."
                className="pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>

          <Tabs defaultValue="all">
            <TabsList>
              <TabsTrigger value="all">All Orders</TabsTrigger>
              <TabsTrigger value="processing">Processing</TabsTrigger>
              <TabsTrigger value="shipped">Shipped</TabsTrigger>
              <TabsTrigger value="delivered">Delivered</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="space-y-6 mt-6">
              {filteredOrders.length > 0 ? (
                filteredOrders.map((order) => (
                  <Card key={order.id}>
                    <CardHeader className="pb-2">
                      <div className="flex flex-col sm:flex-row justify-between gap-2">
                        <div>
                          <CardTitle className="flex items-center gap-2">
                            {order.id}
                            {order.isUrgent && <Badge variant="destructive">Urgent</Badge>}
                          </CardTitle>
                          <CardDescription>Placed on {new Date(order.date).toLocaleDateString()}</CardDescription>
                        </div>
                        <div className="flex items-center gap-2">
                          {getStatusIcon(order.status)}
                          {getStatusBadge(order.status)}
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex flex-wrap gap-4">
                          {order.items.map((item) => (
                            <div key={item.id} className="flex items-center gap-3">
                              <div className="relative h-12 w-12 rounded overflow-hidden">
                                <Image
                                  src={item.image || "/placeholder.svg"}
                                  alt={item.name}
                                  fill
                                  className="object-cover"
                                />
                              </div>
                              <div>
                                <div className="font-medium line-clamp-1">{item.name}</div>
                                <div className="text-sm text-muted-foreground">
                                  ${item.price.toFixed(2)} x {item.quantity}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>

                        <Separator />

                        <div className="flex flex-col sm:flex-row justify-between gap-4">
                          <div className="flex items-center gap-2">
                            <span className="text-muted-foreground">Total:</span>
                            <span className="font-bold">${order.total.toFixed(2)}</span>
                          </div>

                          <div className="flex gap-2">
                            <Button variant="outline" size="sm" asChild>
                              <Link href={`/dashboard/orders/${order.id}`}>View Details</Link>
                            </Button>

                            {order.status === "Delivered" && <Button size="sm">Buy Again</Button>}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <div className="text-center py-12">
                  <div className="flex justify-center mb-4">
                    <Package className="h-12 w-12 text-muted-foreground" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">No orders found</h3>
                  <p className="text-muted-foreground mb-6">
                    {searchQuery ? "No orders match your search criteria" : "You haven't placed any orders yet"}
                  </p>
                  <Button asChild>
                    <Link href="/products">Start Shopping</Link>
                  </Button>
                </div>
              )}
            </TabsContent>

            <TabsContent value="processing" className="space-y-6 mt-6">
              {filteredOrders.filter((order) => order.status.toLowerCase() === "processing").length > 0 ? (
                filteredOrders
                  .filter((order) => order.status.toLowerCase() === "processing")
                  .map((order) => (
                    <Card key={order.id}>
                      <CardHeader className="pb-2">
                        <div className="flex flex-col sm:flex-row justify-between gap-2">
                          <div>
                            <CardTitle className="flex items-center gap-2">
                              {order.id}
                              {order.isUrgent && <Badge variant="destructive">Urgent</Badge>}
                            </CardTitle>
                            <CardDescription>Placed on {new Date(order.date).toLocaleDateString()}</CardDescription>
                          </div>
                          <div className="flex items-center gap-2">
                            {getStatusIcon(order.status)}
                            {getStatusBadge(order.status)}
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div className="flex flex-wrap gap-4">
                            {order.items.map((item) => (
                              <div key={item.id} className="flex items-center gap-3">
                                <div className="relative h-12 w-12 rounded overflow-hidden">
                                  <Image
                                    src={item.image || "/placeholder.svg"}
                                    alt={item.name}
                                    fill
                                    className="object-cover"
                                  />
                                </div>
                                <div>
                                  <div className="font-medium line-clamp-1">{item.name}</div>
                                  <div className="text-sm text-muted-foreground">
                                    ${item.price.toFixed(2)} x {item.quantity}
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>

                          <Separator />

                          <div className="flex flex-col sm:flex-row justify-between gap-4">
                            <div className="flex items-center gap-2">
                              <span className="text-muted-foreground">Total:</span>
                              <span className="font-bold">${order.total.toFixed(2)}</span>
                            </div>

                            <Button variant="outline" size="sm" asChild>
                              <Link href={`/dashboard/orders/${order.id}`}>View Details</Link>
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
              ) : (
                <div className="text-center py-12">
                  <div className="flex justify-center mb-4">
                    <Clock className="h-12 w-12 text-muted-foreground" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">No processing orders</h3>
                  <p className="text-muted-foreground mb-6">You don't have any orders being processed at the moment</p>
                </div>
              )}
            </TabsContent>

            <TabsContent value="shipped" className="space-y-6 mt-6">
              {filteredOrders.filter((order) => order.status.toLowerCase() === "shipped").length > 0 ? (
                filteredOrders
                  .filter((order) => order.status.toLowerCase() === "shipped")
                  .map((order) => (
                    <Card key={order.id}>
                      <CardHeader className="pb-2">
                        <div className="flex flex-col sm:flex-row justify-between gap-2">
                          <div>
                            <CardTitle className="flex items-center gap-2">
                              {order.id}
                              {order.isUrgent && <Badge variant="destructive">Urgent</Badge>}
                            </CardTitle>
                            <CardDescription>Placed on {new Date(order.date).toLocaleDateString()}</CardDescription>
                          </div>
                          <div className="flex items-center gap-2">
                            {getStatusIcon(order.status)}
                            {getStatusBadge(order.status)}
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div className="flex flex-wrap gap-4">
                            {order.items.map((item) => (
                              <div key={item.id} className="flex items-center gap-3">
                                <div className="relative h-12 w-12 rounded overflow-hidden">
                                  <Image
                                    src={item.image || "/placeholder.svg"}
                                    alt={item.name}
                                    fill
                                    className="object-cover"
                                  />
                                </div>
                                <div>
                                  <div className="font-medium line-clamp-1">{item.name}</div>
                                  <div className="text-sm text-muted-foreground">
                                    ${item.price.toFixed(2)} x {item.quantity}
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>

                          <Separator />

                          <div className="flex flex-col sm:flex-row justify-between gap-4">
                            <div className="flex items-center gap-2">
                              <span className="text-muted-foreground">Total:</span>
                              <span className="font-bold">${order.total.toFixed(2)}</span>
                            </div>

                            <Button variant="outline" size="sm" asChild>
                              <Link href={`/dashboard/orders/${order.id}`}>View Details</Link>
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
              ) : (
                <div className="text-center py-12">
                  <div className="flex justify-center mb-4">
                    <Truck className="h-12 w-12 text-muted-foreground" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">No shipped orders</h3>
                  <p className="text-muted-foreground mb-6">You don't have any orders being shipped at the moment</p>
                </div>
              )}
            </TabsContent>

            <TabsContent value="delivered" className="space-y-6 mt-6">
              {filteredOrders.filter((order) => order.status.toLowerCase() === "delivered").length > 0 ? (
                filteredOrders
                  .filter((order) => order.status.toLowerCase() === "delivered")
                  .map((order) => (
                    <Card key={order.id}>
                      <CardHeader className="pb-2">
                        <div className="flex flex-col sm:flex-row justify-between gap-2">
                          <div>
                            <CardTitle className="flex items-center gap-2">
                              {order.id}
                              {order.isUrgent && <Badge variant="destructive">Urgent</Badge>}
                            </CardTitle>
                            <CardDescription>Placed on {new Date(order.date).toLocaleDateString()}</CardDescription>
                          </div>
                          <div className="flex items-center gap-2">
                            {getStatusIcon(order.status)}
                            {getStatusBadge(order.status)}
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div className="flex flex-wrap gap-4">
                            {order.items.map((item) => (
                              <div key={item.id} className="flex items-center gap-3">
                                <div className="relative h-12 w-12 rounded overflow-hidden">
                                  <Image
                                    src={item.image || "/placeholder.svg"}
                                    alt={item.name}
                                    fill
                                    className="object-cover"
                                  />
                                </div>
                                <div>
                                  <div className="font-medium line-clamp-1">{item.name}</div>
                                  <div className="text-sm text-muted-foreground">
                                    ${item.price.toFixed(2)} x {item.quantity}
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>

                          <Separator />

                          <div className="flex flex-col sm:flex-row justify-between gap-4">
                            <div className="flex items-center gap-2">
                              <span className="text-muted-foreground">Total:</span>
                              <span className="font-bold">${order.total.toFixed(2)}</span>
                            </div>

                            <div className="flex gap-2">
                              <Button variant="outline" size="sm" asChild>
                                <Link href={`/dashboard/orders/${order.id}`}>View Details</Link>
                              </Button>

                              <Button size="sm">Buy Again</Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
              ) : (
                <div className="text-center py-12">
                  <div className="flex justify-center mb-4">
                    <Package className="h-12 w-12 text-muted-foreground" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">No delivered orders</h3>
                  <p className="text-muted-foreground mb-6">You don't have any delivered orders yet</p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
