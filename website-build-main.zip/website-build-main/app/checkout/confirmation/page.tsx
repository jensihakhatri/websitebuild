"use client"

import { useState } from "react"
import { useSearchParams } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { CheckCircle2, Clock, Package, Printer, ShoppingBag, Truck } from "lucide-react"

export default function OrderConfirmationPage() {
  const searchParams = useSearchParams()
  const orderId = searchParams.get("orderId") || "ORD-1234"

  const [orderDate] = useState(new Date())
  const [estimatedDelivery] = useState(new Date(Date.now() + 3 * 24 * 60 * 60 * 1000))

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 mb-4">
            <CheckCircle2 className="h-8 w-8 text-green-600" />
          </div>
          <h1 className="text-3xl font-bold">Thank You for Your Order!</h1>
          <p className="text-muted-foreground mt-2">Your order has been placed and is being processed.</p>
        </div>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Order #{orderId}</CardTitle>
            <CardDescription>
              Placed on {orderDate.toLocaleDateString()} at {orderDate.toLocaleTimeString()}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-blue-500" />
                <div>
                  <div className="font-medium">Order Processing</div>
                  <div className="text-sm text-muted-foreground">Your order is being prepared</div>
                </div>
              </div>
              <div className="text-sm text-blue-500 font-medium">Current Status</div>
            </div>

            <div className="relative">
              <Separator className="absolute top-4 left-4 right-4" />
              <div className="relative flex justify-between">
                <div className="flex flex-col items-center z-10">
                  <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center">
                    <CheckCircle2 className="h-4 w-4" />
                  </div>
                  <div className="text-xs mt-1 text-center">Ordered</div>
                </div>

                <div className="flex flex-col items-center z-10">
                  <div className="w-8 h-8 rounded-full bg-blue-500 text-white flex items-center justify-center">
                    <Package className="h-4 w-4" />
                  </div>
                  <div className="text-xs mt-1 text-center">Processing</div>
                </div>

                <div className="flex flex-col items-center z-10">
                  <div className="w-8 h-8 rounded-full bg-muted text-muted-foreground flex items-center justify-center">
                    <Truck className="h-4 w-4" />
                  </div>
                  <div className="text-xs mt-1 text-center">Shipped</div>
                </div>

                <div className="flex flex-col items-center z-10">
                  <div className="w-8 h-8 rounded-full bg-muted text-muted-foreground flex items-center justify-center">
                    <ShoppingBag className="h-4 w-4" />
                  </div>
                  <div className="text-xs mt-1 text-center">Delivered</div>
                </div>
              </div>
            </div>

            <div className="bg-muted p-4 rounded-lg">
              <div className="flex items-start gap-2">
                <Truck className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div>
                  <div className="font-medium">Estimated Delivery</div>
                  <div className="text-sm text-muted-foreground">{estimatedDelivery.toLocaleDateString()}</div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-medium mb-2">Shipping Address</h3>
                <p className="text-sm text-muted-foreground">
                  John Doe
                  <br />
                  123 Main St
                  <br />
                  Anytown, AN 12345
                  <br />
                  Nepal
                </p>
              </div>

              <div>
                <h3 className="font-medium mb-2">Payment Method</h3>
                <p className="text-sm text-muted-foreground">Cash on Delivery</p>
              </div>
            </div>

            <Separator />

            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal</span>
                <span>Rs 154.98</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Shipping</span>
                <span>Free</span>
              </div>
              <div className="flex justify-between font-bold">
                <span>Total</span>
                <span>Rs 154.98</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="flex flex-col sm:flex-row gap-4 justify-between">
          <Button variant="outline" className="flex items-center gap-2">
            <Printer className="h-4 w-4" />
            Print Receipt
          </Button>

          <div className="flex gap-4">
            <Button variant="outline" asChild>
              <Link href="/dashboard/orders">View Orders</Link>
            </Button>

            <Button asChild>
              <Link href="/">Continue Shopping</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
