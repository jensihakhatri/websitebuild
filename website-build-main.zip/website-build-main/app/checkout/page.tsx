"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Separator } from "@/components/ui/separator"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { useToast } from "@/components/ui/use-toast"
import { Check, CreditCard, Phone } from "lucide-react"

// Mock cart data
const cartItems = [
  {
    id: 1,
    name: "Wireless Bluetooth Headphones",
    price: 129.99,
    quantity: 1,
    image: "/placeholder.svg?height=80&width=80",
    discount: 15,
  },
  {
    id: 3,
    name: "Premium Cotton T-Shirt",
    price: 24.99,
    quantity: 2,
    image: "/placeholder.svg?height=80&width=80",
    discount: 0,
  },
]

export default function CheckoutPage() {
  const router = useRouter()
  const { toast } = useToast()

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    zipCode: "",
    country: "Nepal",
    paymentMethod: "cash",
    isUrgent: false,
    urgentNote: "",
  })

  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData({
      ...formData,
      [name]: value,
    })
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData({
      ...formData,
      [name]: value,
    })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false)

      // Generate a random order ID
      const orderId = `ORD-${Math.floor(Math.random() * 10000)}`

      toast({
        title: "Order Placed Successfully!",
        description: `Your order #${orderId} has been placed. Thank you for shopping with us!`,
      })

      // Redirect to order confirmation page
      router.push(`/checkout/confirmation?orderId=${orderId}`)
    }, 2000)
  }

  const calculateSubtotal = () => {
    return cartItems.reduce((total, item) => {
      const discountedPrice = item.discount > 0 ? item.price * (1 - item.discount / 100) : item.price
      return total + discountedPrice * item.quantity
    }, 0)
  }

  const subtotal = calculateSubtotal()
  const shipping = subtotal > 50 ? 0 : 5.99
  const total = subtotal + shipping

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row gap-8">
        <div className="md:w-2/3">
          <div className="mb-6">
            <h1 className="text-3xl font-bold">Checkout</h1>
            <p className="text-muted-foreground">Complete your order by providing your shipping and payment details.</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-8">
            <div className="space-y-4">
              <h2 className="text-xl font-semibold">Contact Information</h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="firstName">First Name</Label>
                  <Input
                    id="firstName"
                    name="firstName"
                    value={formData.firstName}
                    onChange={handleInputChange}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="lastName">Last Name</Label>
                  <Input
                    id="lastName"
                    name="lastName"
                    value={formData.lastName}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input id="phone" name="phone" value={formData.phone} onChange={handleInputChange} required />
                </div>
              </div>
            </div>

            <Separator />

            <div className="space-y-4">
              <h2 className="text-xl font-semibold">Shipping Address</h2>

              <div className="space-y-2">
                <Label htmlFor="address">Street Address</Label>
                <Input id="address" name="address" value={formData.address} onChange={handleInputChange} required />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="city">City</Label>
                  <Input id="city" name="city" value={formData.city} onChange={handleInputChange} required />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="state">State/Province</Label>
                  <Input id="state" name="state" value={formData.state} onChange={handleInputChange} required />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="zipCode">ZIP / Postal Code</Label>
                  <Input id="zipCode" name="zipCode" value={formData.zipCode} onChange={handleInputChange} required />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="country">Country</Label>
                <Select value={formData.country} onValueChange={(value) => handleSelectChange("country", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select country" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Nepal">Nepal</SelectItem>
                    <SelectItem value="India">India</SelectItem>
                    <SelectItem value="Bangladesh">Bangladesh</SelectItem>
                    <SelectItem value="Sri Lanka">Sri Lanka</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Separator />

            <div className="space-y-4">
              <h2 className="text-xl font-semibold">Payment Method</h2>

              <RadioGroup
                value={formData.paymentMethod}
                onValueChange={(value) => handleSelectChange("paymentMethod", value)}
                className="space-y-4"
              >
                <div className="flex items-center space-x-2 border rounded-md p-4">
                  <RadioGroupItem value="cash" id="cash" />
                  <Label htmlFor="cash" className="flex items-center gap-2 cursor-pointer">
                    <CreditCard className="h-5 w-5" />
                    Cash on Delivery
                  </Label>
                </div>

                <div className="flex items-center space-x-2 border rounded-md p-4">
                  <RadioGroupItem value="esewa" id="esewa" />
                  <Label htmlFor="esewa" className="cursor-pointer">
                    <div className="flex items-center gap-2">
                      <div className="h-5 w-5 bg-green-500 rounded-sm flex items-center justify-center text-white text-xs font-bold">
                        E
                      </div>
                      Esewa
                    </div>
                  </Label>
                </div>
              </RadioGroup>

              {formData.paymentMethod === "esewa" && (
                <div className="bg-blue-50 border border-blue-200 rounded-md p-4">
                  <div className="flex items-start gap-2">
                    <Phone className="h-5 w-5 text-blue-500 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-blue-700">WhatsApp Payment Instructions</h4>
                      <p className="text-sm text-blue-600 mb-2">
                        After placing your order, please send the payment to our Esewa account and send us the payment
                        confirmation via WhatsApp.
                      </p>
                      <div className="flex items-center gap-2 text-sm font-medium text-blue-700">
                        <span>WhatsApp:</span>
                        <a href="https://wa.me/1234567890" className="underline">
                          +1234567890
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <Separator />

            <div className="space-y-4">
              <h2 className="text-xl font-semibold">Additional Information</h2>

              <div className="flex items-start space-x-2 p-4 bg-muted rounded-lg">
                <input
                  type="checkbox"
                  id="urgent-order"
                  checked={formData.isUrgent}
                  onChange={(e) => setFormData({ ...formData, isUrgent: e.target.checked })}
                  className="mt-1"
                />
                <div className="space-y-1">
                  <Label htmlFor="urgent-order" className="font-medium">
                    Mark as Urgent Order
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    Urgent orders are prioritized and shipped within 24 hours.
                  </p>
                  {formData.isUrgent && (
                    <Textarea
                      placeholder="Add any special instructions for your urgent order..."
                      name="urgentNote"
                      value={formData.urgentNote}
                      onChange={handleInputChange}
                      className="mt-2"
                    />
                  )}
                </div>
              </div>

              <Accordion type="single" collapsible>
                <AccordionItem value="notes">
                  <AccordionTrigger>Order Notes (Optional)</AccordionTrigger>
                  <AccordionContent>
                    <Textarea
                      placeholder="Notes about your order, e.g. special notes for delivery"
                      className="min-h-[100px]"
                    />
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </div>

            <div className="pt-4">
              <Button type="submit" className="w-full" size="lg" disabled={isSubmitting}>
                {isSubmitting ? "Processing..." : "Place Order"}
              </Button>
            </div>
          </form>
        </div>

        <div className="md:w-1/3">
          <div className="rounded-lg border p-6 space-y-6 sticky top-20">
            <h2 className="text-xl font-bold">Order Summary</h2>

            <div className="space-y-4">
              {cartItems.map((item) => {
                const discountedPrice = item.discount > 0 ? item.price * (1 - item.discount / 100) : item.price

                return (
                  <div key={item.id} className="flex gap-4">
                    <div className="relative h-16 w-16 rounded overflow-hidden flex-shrink-0">
                      <Image src={item.image || "/placeholder.svg"} alt={item.name} fill className="object-cover" />
                      <div className="absolute top-0 right-0 bg-primary text-primary-foreground w-5 h-5 rounded-full flex items-center justify-center text-xs">
                        {item.quantity}
                      </div>
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium line-clamp-1">{item.name}</h3>
                      <div className="text-sm text-muted-foreground">
                        Rs {discountedPrice.toFixed(2)} x {item.quantity}
                      </div>
                      {item.discount > 0 && <div className="text-xs text-red-600">-{item.discount}% OFF</div>}
                    </div>
                    <div className="font-medium">Rs {(discountedPrice * item.quantity).toFixed(2)}</div>
                  </div>
                )
              })}
            </div>

            <Separator />

            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal</span>
                <span>Rs {subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Shipping</span>
                <span>{shipping === 0 ? "Free" : `Rs ${shipping.toFixed(2)}`}</span>
              </div>
              {shipping > 0 && <div className="text-xs text-muted-foreground">Free shipping on orders over $50</div>}
            </div>

            <Separator />

            <div className="flex justify-between text-lg font-bold">
              <span>Total</span>
              <span>Rs {total.toFixed(2)}</span>
            </div>

            <div className="bg-muted p-4 rounded-lg text-sm space-y-2">
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>Secure Checkout</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>Free Returns</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>30-Day Money Back Guarantee</span>
              </div>
            </div>

            <div className="text-sm text-muted-foreground">
              By placing your order, you agree to our{" "}
              <Link href="/terms" className="text-primary hover:underline">
                Terms of Service
              </Link>{" "}
              and{" "}
              <Link href="/privacy" className="text-primary hover:underline">
                Privacy Policy
              </Link>
              .
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
